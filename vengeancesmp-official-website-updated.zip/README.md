<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/57060f22-6490-4ee7-a083-c34c0998a684

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## VengeanceSMP continuation update

- The homepage now spotlights JstWrxth, ItzSwiftonic, Kyron, Kingcoolcat, and EvolutionBattle instead of faction cards.
- Each character currently links to a YouTube search because exact channel URLs have not been supplied yet. Replace those search links with each creator's channel URL when available.
- Latest Uploads is clearly marked Under Development until the exact channels/feed IDs are configured. YouTube's public channel feeds can support a future live latest-upload section; channel IDs are needed to wire this accurately.
- Server status uses a public status lookup and refreshes every 60 seconds. Player counts and version are never simulated; unavailable status is shown as unavailable.
