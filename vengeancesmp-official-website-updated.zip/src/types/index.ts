export type PageView = 
  | 'home' 
  | 'scripted' 
  | 'unscripted' 
  | 'tier-list' 
  | 'promotion' 
  | 'rules' 
  | 'about' 
  | 'events' 
  | 'news' 
  | 'faq' 
  | 'staff' 
  | 'contact';

export type SlideMode = 'unscripted' | 'scripted';

export type FactionId = 'obsidian' | 'sunforge' | 'ashen' | 'lone_wolf';

export interface Faction {
  id: FactionId;
  name: string;
  tag: string;
  color: string;
  bannerColor: string;
  leader: string;
  motto: string;
  description: string;
  baseCoordinates: string;
  territoryPercent: number;
  activeWarWith: string;
}

export type ScriptedRoleCategory = 
  | 'Main Characters' 
  | 'Important Characters' 
  | 'Side Characters' 
  | 'Antagonists' 
  | 'Builders' 
  | 'PvPers';

export interface MemberProfile {
  id: string;
  username: string;
  role: string;
  scriptedCategory?: ScriptedRoleCategory;
  faction: FactionId;
  joinDate: string;
  kills: number;
  deaths: number;
  kdRatio: number;
  bounty: number;
  playtimeHours: number;
  favoriteWeapon: string;
  weaponLore: string;
  gearTier: 'Netherite Max' | 'Netherite' | 'Diamond Pro' | 'Enchanted Hybrid';
  bio: string;
  quote: string;
  avatarSeed: string;
  combatStyle: 'Aggressive Rusher' | 'Crystal PvP Elite' | 'Bow Sniper' | 'Trap Master' | 'Tactical Support';
  canonLives: number;
  status: 'Online' | 'AFK' | 'Offline';
  loadout: {
    helmet: string;
    chestplate: string;
    leggings: string;
    boots: string;
    mainHand: string;
    offHand: string;
    specialItems: string[];
  };
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  faction: FactionId;
  kills: number;
  deaths: number;
  kdRatio: number;
  bounty: number;
  playtimeHours: number;
  streak: number;
  tier: 'Immortal' | 'Grandmaster' | 'Warlord' | 'Veteran' | 'Gladiator';
}

export interface ServerRule {
  id: string;
  number: number;
  category: 'Combat & PvP' | 'Raiding & Griefing' | 'Exploits & Fair Play' | 'Economy & Trading' | 'Community Conduct';
  title: string;
  shortDescription: string;
  fullRule: string;
  penalty: 'Permanent Ban' | '7-Day Ban' | '3-Day Ban' | 'Inventory Wipe & Jail' | 'Warning / Mute';
  severity: 'critical' | 'high' | 'medium';
  examplesAllowed: string[];
  examplesProhibited: string[];
}

export interface CanonDeath {
  lifeNumber: 1 | 2 | 3;
  episodeTitle: string;
  episodeNumber: number;
  killer: string;
  cause: string;
  description: string;
}

export interface LoreCharacter {
  id: string;
  username: string;
  characterName: string;
  title: string;
  roleCategory: ScriptedRoleCategory;
  faction: FactionId;
  canonLives: number;
  moralAlignment: 'Lawful Good' | 'Chaotic Neutral' | 'Lawful Evil' | 'Chaotic Evil' | 'True Neutral';
  deaths: CanonDeath[];
  characterArc: string;
  keyMotive: string;
  signatureArtifact: string;
  status: 'Alive' | 'On Last Life' | 'Fallen (Ghost)';
}

export interface ScriptEpisode {
  id: string;
  episodeNumber: number;
  season: number;
  title: string;
  synopsis: string;
  keyMoments: string[];
  canonEvents: string[];
  keyQuote: string;
  speaker: string;
  transcriptExcerpt: {
    speaker: string;
    line: string;
    stageDirection?: string;
  }[];
}

export interface ServerEvent {
  id: string;
  title: string;
  date: string;
  type: 'Scripted Canon Event' | 'Unscripted Launch' | 'PvP Tournament' | 'Civilization Summit';
  description: string;
  location: string;
  status: 'Upcoming' | 'In Progress' | 'Completed';
}

export interface NewsPost {
  id: string;
  title: string;
  date: string;
  tag: string;
  summary: string;
  content: string;
}
