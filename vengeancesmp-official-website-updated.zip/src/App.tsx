/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { ParticleBackground } from './components/ParticleBackground';
import { UnderDevelopmentBanner } from './components/UnderDevelopmentBanner';
import { HomePage } from './components/HomePage';
import { ScriptedSlide } from './components/ScriptedSlide';
import { UnscriptedSlide } from './components/UnscriptedSlide';
import { TierListPage } from './components/TierListPage';
import { PromotionPage } from './components/PromotionPage';
import { ExtraPages } from './components/ExtraPages';
import { MemberModal } from './components/MemberModal';
import { ScriptModal } from './components/ScriptModal';
import { ContactModal } from './components/ContactModal';
import { Footer } from './components/Footer';
import { PageView, MemberProfile, ScriptEpisode } from './types';
import { sound } from './utils/audio';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [selectedMember, setSelectedMember] = useState<MemberProfile | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<ScriptEpisode | null>(null);
  const [isContactOpen, setIsContactOpen] = useState<boolean>(false);

  // Under Development 2-second alert state
  const [underDevBanner, setUnderDevBanner] = useState<{
    isOpen: boolean;
    message: string;
  }>({
    isOpen: false,
    message: ''
  });

  const handleToggleSound = () => {
    sound.enabled = !sound.enabled;
    setSoundEnabled(sound.enabled);
  };

  const handleNavigate = (page: PageView) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const triggerUnderDevelopment = (message: string) => {
    setUnderDevBanner({
      isOpen: true,
      message
    });
  };

  return (
    <div className="relative min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-red-600 selection:text-white flex flex-col justify-between overflow-x-hidden">
      {/* Ambient Minecraft Nether/Void floating ember particles */}
      <ParticleBackground />

      {/* 2-Second Animated Under Development Toast / Banner */}
      <UnderDevelopmentBanner
        isOpen={underDevBanner.isOpen}
        message={underDevBanner.message}
        onClose={() => setUnderDevBanner((prev) => ({ ...prev, isOpen: false }))}
      />

      <div className="relative z-10">
        {/* Main Navigation Bar */}
        <Navbar
          currentPage={currentPage}
          onNavigate={handleNavigate}
          onTriggerUnderDevelopment={triggerUnderDevelopment}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
        />

        {/* Dynamic Page Views */}
        <main className="w-full transition-opacity duration-200">
          {currentPage === 'home' && (
            <HomePage
              onNavigate={handleNavigate}
              onTriggerUnderDevelopment={triggerUnderDevelopment}
            />
          )}

          {currentPage === 'scripted' && (
            <ScriptedSlide
              onSelectEpisode={(ep) => setSelectedEpisode(ep)}
              onTriggerUnderDevelopment={triggerUnderDevelopment}
            />
          )}

          {currentPage === 'unscripted' && (
            <UnscriptedSlide
              onSelectMember={(mem) => setSelectedMember(mem)}
            />
          )}

          {currentPage === 'tier-list' && (
            <TierListPage
              onTriggerUnderDevelopment={triggerUnderDevelopment}
            />
          )}

          {currentPage === 'promotion' && (
            <PromotionPage
              onOpenContact={() => setIsContactOpen(true)}
              onTriggerUnderDevelopment={triggerUnderDevelopment}
            />
          )}

          {(currentPage === 'rules' || 
            currentPage === 'about' || 
            currentPage === 'events' || 
            currentPage === 'news' || 
            currentPage === 'faq' || 
            currentPage === 'staff') && (
            <ExtraPages
              view={currentPage}
              onNavigate={handleNavigate}
              onOpenContact={() => setIsContactOpen(true)}
              onTriggerUnderDevelopment={triggerUnderDevelopment}
            />
          )}

          {currentPage === 'contact' && (
            <div className="mx-auto max-w-2xl px-4 py-16 text-center space-y-4">
              <h2 className="font-cinzel text-3xl font-bold text-white">Contact & Support</h2>
              <p className="text-sm text-zinc-400">
                You can submit tickets through our direct form or reach out in Discord.
              </p>
              <button
                onClick={() => setIsContactOpen(true)}
                className="rounded-xl bg-red-600 px-6 py-3 text-xs font-bold text-white hover:bg-red-500"
              >
                Open Ticket Dispatcher
              </button>
            </div>
          )}
        </main>
      </div>

      {/* Modals */}
      <MemberModal
        member={selectedMember}
        onClose={() => setSelectedMember(null)}
      />

      <ScriptModal
        episode={selectedEpisode}
        onClose={() => setSelectedEpisode(null)}
      />

      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      {/* Quiet, Cinematic Footer with Large Discord Banner */}
      <Footer
        onNavigate={handleNavigate}
        onTriggerUnderDevelopment={triggerUnderDevelopment}
      />
    </div>
  );
}
