import React, { useState } from 'react';
import { 
  Volume2, VolumeX, Swords, Scroll, Trophy, Megaphone, 
  Disc as DiscordIcon, Menu, X, MoreHorizontal, Shield, 
  HelpCircle, Calendar, Newspaper, UserCheck, Mail, Info 
} from 'lucide-react';
import { PageView } from '../types';
import { SERVER_CONFIG } from '../data/serverData';
import { sound } from '../utils/audio';

interface NavbarProps {
  currentPage: PageView;
  onNavigate: (page: PageView) => void;
  onTriggerUnderDevelopment: (feature: string) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  onTriggerUnderDevelopment,
  soundEnabled,
  onToggleSound
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const handleNav = (page: PageView) => {
    sound.playClick();
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);

    if (page === 'tier-list') {
      // Per instructions: "When the user clicks the Tier List button, open the Tier List section/page.
      // If the feature is not ready, display an animated message: UNDER DEVELOPMENT. Keep it visible for approximately 2 seconds, then allow the user to continue browsing."
      onNavigate('tier-list');
      onTriggerUnderDevelopment('Tier List ranking engine is currently in active calibration.');
      return;
    }

    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExtraButton = (page: PageView, isUnfinished: boolean = false, name: string = '') => {
    sound.playClick();
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);

    if (isUnfinished) {
      onTriggerUnderDevelopment(`${name} is currently under active development.`);
      return;
    }

    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-800/80 bg-zinc-950/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Lockup */}
        <button
          onClick={() => handleNav('home')}
          className="group flex items-center gap-2 text-left focus-visible:outline-none"
        >
          <span className="font-cinzel text-xl font-extrabold tracking-wider text-red-500 transition-colors group-hover:text-red-400">
            VENGEANCE<span className="text-zinc-100">.</span>
          </span>
        </button>

        {/* Main Desktop Navigation */}
        <nav className="hidden items-center gap-1 lg:flex">
          <button
            onClick={() => handleNav('home')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              currentPage === 'home'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900/60'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => handleNav('scripted')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              currentPage === 'scripted'
                ? 'bg-purple-950/70 border border-purple-800 text-purple-200'
                : 'text-zinc-400 hover:text-purple-300 hover:bg-zinc-900/60'
            }`}
          >
            <Scroll className="h-3.5 w-3.5" />
            <span>Scripted SMP</span>
          </button>

          <button
            onClick={() => handleNav('unscripted')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              currentPage === 'unscripted'
                ? 'bg-red-950/70 border border-red-800 text-red-200'
                : 'text-zinc-400 hover:text-red-300 hover:bg-zinc-900/60'
            }`}
          >
            <Swords className="h-3.5 w-3.5" />
            <span>Unscripted SMP</span>
          </button>

          <button
            onClick={() => handleNav('tier-list')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              currentPage === 'tier-list'
                ? 'bg-amber-950/70 border border-amber-800 text-amber-200'
                : 'text-zinc-400 hover:text-amber-300 hover:bg-zinc-900/60'
            }`}
          >
            <Trophy className="h-3.5 w-3.5" />
            <span>Tier List</span>
          </button>

          <button
            onClick={() => handleNav('promotion')}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              currentPage === 'promotion'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900/60'
            }`}
          >
            <Megaphone className="h-3.5 w-3.5" />
            <span>Promotion</span>
          </button>

          {/* More Useful Buttons Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
              className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900/60"
            >
              <span>Explore</span>
              <MoreHorizontal className="h-3.5 w-3.5" />
            </button>

            {moreDropdownOpen && (
              <div
                className="absolute right-0 top-full mt-2 w-52 rounded-xl border border-zinc-800 bg-zinc-950 p-2 shadow-2xl backdrop-blur-xl z-50 animate-in fade-in duration-150"
                onMouseLeave={() => setMoreDropdownOpen(false)}
              >
                <button
                  onClick={() => handleExtraButton('rules')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <Shield className="h-3.5 w-3.5 text-red-400" />
                  <span>Rules</span>
                </button>
                <button
                  onClick={() => handleExtraButton('about')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <Info className="h-3.5 w-3.5 text-blue-400" />
                  <span>About Vengeance</span>
                </button>
                <button
                  onClick={() => handleExtraButton('events')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <Calendar className="h-3.5 w-3.5 text-amber-400" />
                  <span>Events</span>
                </button>
                <button
                  onClick={() => handleExtraButton('news')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <Newspaper className="h-3.5 w-3.5 text-purple-400" />
                  <span>News & Updates</span>
                </button>
                <button
                  onClick={() => handleExtraButton('faq')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <HelpCircle className="h-3.5 w-3.5 text-emerald-400" />
                  <span>FAQ</span>
                </button>
                <button
                  onClick={() => handleExtraButton('staff')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <UserCheck className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Staff Team</span>
                </button>
                <button
                  onClick={() => handleExtraButton('contact')}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-900 hover:text-white"
                >
                  <Mail className="h-3.5 w-3.5 text-rose-400" />
                  <span>Contact Us</span>
                </button>
                <div className="my-1 border-t border-zinc-800" />
                <button
                  onClick={() => handleExtraButton('home', true, 'Character Applications Portal')}
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200"
                >
                  <span>Character Auditions</span>
                  <span className="text-[10px] text-amber-500 font-semibold">SOON</span>
                </button>
              </div>
            )}
          </div>
        </nav>

        {/* Right Action: Discord Button & Sound FX Toggle */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              if (!soundEnabled) sound.playClick();
            }}
            title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-800 bg-zinc-900/80 text-zinc-400 transition-colors hover:border-zinc-700 hover:text-zinc-200"
            aria-label="Toggle Sound"
          >
            {soundEnabled ? <Volume2 className="h-4 w-4 text-emerald-400" /> : <VolumeX className="h-4 w-4 text-zinc-500" />}
          </button>

          {/* Discord CTA Button (Mandatory in navigation) */}
          <a
            href={SERVER_CONFIG.discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => sound.playLevelUp()}
            className="flex items-center gap-1.5 rounded-lg border border-indigo-500/50 bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-lg shadow-indigo-950 transition-all hover:bg-indigo-500 active:scale-[0.98]"
          >
            <span>Discord</span>
          </a>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white lg:hidden"
            aria-label="Open Navigation Menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="border-b border-zinc-800 bg-zinc-950/98 p-4 lg:hidden animate-in slide-in-from-top-2 duration-150 space-y-2">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <button
              onClick={() => handleNav('home')}
              className={`rounded-lg p-2.5 text-left ${currentPage === 'home' ? 'bg-red-600 text-white' : 'bg-zinc-900 text-zinc-300'}`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('scripted')}
              className={`rounded-lg p-2.5 text-left ${currentPage === 'scripted' ? 'bg-purple-600 text-white' : 'bg-zinc-900 text-zinc-300'}`}
            >
              Scripted SMP
            </button>
            <button
              onClick={() => handleNav('unscripted')}
              className={`rounded-lg p-2.5 text-left ${currentPage === 'unscripted' ? 'bg-red-700 text-white' : 'bg-zinc-900 text-zinc-300'}`}
            >
              Unscripted SMP
            </button>
            <button
              onClick={() => handleNav('tier-list')}
              className={`rounded-lg p-2.5 text-left ${currentPage === 'tier-list' ? 'bg-amber-600 text-white' : 'bg-zinc-900 text-zinc-300'}`}
            >
              Tier List
            </button>
            <button
              onClick={() => handleNav('promotion')}
              className={`rounded-lg p-2.5 text-left ${currentPage === 'promotion' ? 'bg-zinc-700 text-white' : 'bg-zinc-900 text-zinc-300'}`}
            >
              Promotion
            </button>
            <a
              href={SERVER_CONFIG.discordUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-lg p-2.5 text-left bg-indigo-600 text-white font-semibold flex items-center justify-between"
            >
              <span>Join Discord</span>
              <span className="text-[10px]">↗</span>
            </a>
          </div>

          <div className="border-t border-zinc-800 pt-3">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500 block mb-2">
              Server Information & Extras
            </span>
            <div className="grid grid-cols-2 gap-1.5 text-xs text-zinc-400">
              <button onClick={() => handleExtraButton('rules')} className="text-left p-1.5 hover:text-white">
                Rules Codex
              </button>
              <button onClick={() => handleExtraButton('about')} className="text-left p-1.5 hover:text-white">
                About Vengeance
              </button>
              <button onClick={() => handleExtraButton('events')} className="text-left p-1.5 hover:text-white">
                Server Events
              </button>
              <button onClick={() => handleExtraButton('news')} className="text-left p-1.5 hover:text-white">
                News & 1.21.11
              </button>
              <button onClick={() => handleExtraButton('faq')} className="text-left p-1.5 hover:text-white">
                FAQ
              </button>
              <button onClick={() => handleExtraButton('staff')} className="text-left p-1.5 hover:text-white">
                Staff Team
              </button>
              <button onClick={() => handleExtraButton('contact')} className="text-left p-1.5 hover:text-white">
                Contact Us
              </button>
              <button 
                onClick={() => handleExtraButton('home', true, 'Character Application Portal')} 
                className="text-left p-1.5 text-amber-500"
              >
                Applications (Dev)
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
