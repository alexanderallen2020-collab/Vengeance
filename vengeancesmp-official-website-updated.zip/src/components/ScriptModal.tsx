import React from 'react';
import { X, BookOpen, Quote, Sparkles } from 'lucide-react';
import { ScriptEpisode } from '../types';
import { sound } from '../utils/audio';

interface ScriptModalProps {
  episode: ScriptEpisode | null;
  onClose: () => void;
}

export const ScriptModal: React.FC<ScriptModalProps> = ({ episode, onClose }) => {
  if (!episode) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={() => {
        sound.playClick();
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-2xl overflow-hidden rounded-xl border border-zinc-700 bg-zinc-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner */}
        <div className="relative border-b border-zinc-800 bg-gradient-to-r from-purple-950 via-zinc-900 to-zinc-950 p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-400">
                <BookOpen className="h-3.5 w-3.5" />
                <span>Season {episode.season} · Episode {episode.episodeNumber} Canon Transcript</span>
              </div>
              <h2 className="font-cinzel text-2xl font-bold text-white mt-1">{episode.title}</h2>
              <p className="mt-1 text-xs text-zinc-400">{episode.synopsis}</p>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Script Dialogue Content */}
        <div className="max-h-[70vh] overflow-y-auto p-6 space-y-4 font-mono text-xs">
          <div className="rounded-lg border border-purple-500/30 bg-purple-950/20 p-3 italic text-purple-200 flex items-start gap-2">
            <Quote className="h-4 w-4 shrink-0 text-purple-400 mt-0.5" />
            <div>
              <span className="font-bold">{episode.speaker}: </span>"{episode.keyQuote}"
            </div>
          </div>

          <div className="space-y-4 pt-2">
            <span className="text-[11px] font-sans font-semibold uppercase tracking-wider text-zinc-500 block">
              Official Dialogue Excerpt
            </span>
            {episode.transcriptExcerpt.map((entry, index) => (
              <div key={index} className="rounded border border-zinc-800 bg-zinc-950/60 p-3 space-y-1">
                <span className="font-bold text-red-400 uppercase tracking-wide">
                  [{entry.speaker}]
                </span>
                {entry.stageDirection && (
                  <p className="text-zinc-500 italic text-[11px]">
                    * {entry.stageDirection} *
                  </p>
                )}
                <p className="text-zinc-200 leading-relaxed text-xs">
                  {entry.line}
                </p>
              </div>
            ))}
          </div>

          <div className="rounded border border-zinc-800 bg-zinc-950/40 p-3">
            <span className="text-[11px] font-sans font-semibold uppercase tracking-wider text-zinc-500 block">
              Canon Consequences
            </span>
            <ul className="mt-1 space-y-1 list-disc list-inside text-zinc-400">
              {episode.canonEvents.map((evt, idx) => (
                <li key={idx}>{evt}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-zinc-800 bg-zinc-950 px-6 py-3 text-xs text-zinc-400">
          <span>VengeanceSMP Lore Archives</span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="rounded bg-zinc-800 px-3 py-1 font-medium text-zinc-200 hover:bg-zinc-700"
          >
            Close Script
          </button>
        </div>
      </div>
    </div>
  );
};
