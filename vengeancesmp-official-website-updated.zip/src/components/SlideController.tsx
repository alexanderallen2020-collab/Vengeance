import React, { useEffect } from 'react';
import { ChevronLeft, ChevronRight, Swords, BookOpen, Sparkles } from 'lucide-react';
import { SlideMode } from '../types';
import { sound } from '../utils/audio';

interface SlideControllerProps {
  currentSlide: SlideMode;
  onSwitchSlide: (slide: SlideMode) => void;
}

export const SlideController: React.FC<SlideControllerProps> = ({
  currentSlide,
  onSwitchSlide
}) => {
  // Support Left/Right Arrow keyboard shortcuts for seamless presentation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.key === 'ArrowRight' || e.key === '2') {
        if (currentSlide !== 'scripted') {
          sound.playWarp();
          onSwitchSlide('scripted');
        }
      } else if (e.key === 'ArrowLeft' || e.key === '1') {
        if (currentSlide !== 'unscripted') {
          sound.playWarp();
          onSwitchSlide('unscripted');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide, onSwitchSlide]);

  return (
    <div className="w-full border-b border-zinc-800/60 bg-zinc-950/60 backdrop-blur-sm">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        {/* Left: Mode Title & Info */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-zinc-400">
            <span className="font-semibold uppercase tracking-wider text-zinc-500">Presentation Mode:</span>
            <span className="font-code text-zinc-300">
              {currentSlide === 'unscripted' ? 'SLIDE 1 OF 2' : 'SLIDE 2 OF 2'}
            </span>
          </div>

          <span className="hidden text-zinc-700 sm:inline">|</span>

          <span className="hidden text-xs text-zinc-400 lg:inline">
            {currentSlide === 'unscripted'
              ? 'Unscripted Survival · Server Rules · Member Profiles · Leaderboard System'
              : 'Scripted Lore · 3 Canon Lives System · Story Chronicles'}
          </span>
        </div>

        {/* Right: Slide Controls */}
        <div className="flex items-center gap-2">
          {/* Slide 1 Button */}
          <button
            onClick={() => {
              sound.playWarp();
              onSwitchSlide('unscripted');
            }}
            className={`group relative flex items-center gap-2 rounded-lg border px-3.5 py-1.5 text-xs font-semibold transition-all ${
              currentSlide === 'unscripted'
                ? 'border-red-500/70 bg-red-950/60 text-white shadow-lg shadow-red-950/40 ring-1 ring-red-500/30'
                : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
            }`}
          >
            <Swords className={`h-3.5 w-3.5 ${currentSlide === 'unscripted' ? 'text-red-400' : 'text-zinc-500'}`} />
            <span>Slide 1: Unscripted SMP</span>
            {currentSlide === 'unscripted' && (
              <span className="h-1.5 w-1.5 rounded-full bg-red-400 animate-pulse" />
            )}
          </button>

          {/* Slide 2 Button */}
          <button
            onClick={() => {
              sound.playWarp();
              onSwitchSlide('scripted');
            }}
            className={`group relative flex items-center gap-2 rounded-lg border px-3.5 py-1.5 text-xs font-semibold transition-all ${
              currentSlide === 'scripted'
                ? 'border-purple-500/70 bg-purple-950/60 text-white shadow-lg shadow-purple-950/40 ring-1 ring-purple-500/30'
                : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
            }`}
          >
            <BookOpen className={`h-3.5 w-3.5 ${currentSlide === 'scripted' ? 'text-purple-400' : 'text-zinc-500'}`} />
            <span>Slide 2: Scripted SMP</span>
            {currentSlide === 'scripted' && (
              <span className="h-1.5 w-1.5 rounded-full bg-purple-400 animate-pulse" />
            )}
          </button>

          {/* Quick Prev / Next Arrows */}
          <div className="ml-1 flex items-center gap-1 border-l border-zinc-800 pl-2">
            <button
              onClick={() => {
                sound.playWarp();
                onSwitchSlide('unscripted');
              }}
              disabled={currentSlide === 'unscripted'}
              title="Previous Slide (Unscripted SMP) [Key: ←]"
              className="flex h-7 w-7 items-center justify-center rounded border border-zinc-800 bg-zinc-900/60 text-zinc-400 transition-colors hover:text-zinc-100 disabled:opacity-30 disabled:hover:text-zinc-400"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => {
                sound.playWarp();
                onSwitchSlide('scripted');
              }}
              disabled={currentSlide === 'scripted'}
              title="Next Slide (Scripted SMP) [Key: →]"
              className="flex h-7 w-7 items-center justify-center rounded border border-zinc-800 bg-zinc-900/60 text-zinc-400 transition-colors hover:text-zinc-100 disabled:opacity-30 disabled:hover:text-zinc-400"
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
