import React, { useState } from 'react';
import { 
  Trophy, Hammer, Swords, Building2, Brain, Crown, 
  Coins, Sparkles, Send, CheckCircle2, Clock, AlertCircle 
} from 'lucide-react';
import { TIER_LIST_CATEGORIES } from '../data/serverData';
import { sound } from '../utils/audio';

interface TierListPageProps {
  onTriggerUnderDevelopment: (feature: string) => void;
}

export const TierListPage: React.FC<TierListPageProps> = ({ onTriggerUnderDevelopment }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('pvp');
  const [suggestedMetric, setSuggestedMetric] = useState('');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  const handleVote = (categoryName: string) => {
    sound.playLevelUp();
    onTriggerUnderDevelopment(`Your vote for the ${categoryName} tier list has been recorded in the dev backlog!`);
  };

  const handleSuggest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!suggestedMetric.trim()) return;
    sound.playLevelUp();
    setSubmittedFeedback(true);
    setTimeout(() => {
      setSuggestedMetric('');
      setSubmittedFeedback(false);
    }, 3000);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border-2 border-amber-500/50 bg-gradient-to-r from-amber-950/40 via-zinc-950 to-zinc-950 p-8 sm:p-12 shadow-2xl">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/40 bg-amber-950/60 px-3.5 py-1 text-xs font-semibold text-amber-300">
            <Hammer className="h-3.5 w-3.5 animate-bounce text-amber-400" />
            <span>CURRENTLY UNDER DEVELOPMENT</span>
          </div>

          <h1 className="font-cinzel text-4xl sm:text-6xl font-extrabold text-white">
            Tier List
          </h1>

          <p className="font-cinzel text-lg sm:text-xl font-bold text-amber-400">
            Currently Under Development
          </p>

          <p className="text-sm sm:text-base text-zinc-300 leading-relaxed max-w-2xl">
            Vengeance's tier system is currently being developed. To avoid arbitrary scores, the team is designing a transparent metrics system for competitive players.
          </p>

          <div className="flex items-center gap-3 pt-2 text-xs text-zinc-400">
            <span className="flex items-center gap-1 text-amber-400 font-semibold">
              <Clock className="h-3.5 w-3.5" /> Target Release: Next Core Season Patch
            </span>
            <span>·</span>
            <span>Community Voting Open Below</span>
          </div>
        </div>
      </div>

      {/* Planned Categories Grid */}
      <div className="space-y-6">
        <div className="border-b border-zinc-800 pb-4 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
              System Architecture
            </span>
            <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-white mt-0.5">
              Future Evaluation Categories
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Explore the upcoming competitive rating brackets planned for Vengeance.
            </p>
          </div>
          <span className="font-code text-xs text-zinc-500">6 Disciplines Planned</span>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {TIER_LIST_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <div
                key={cat.id}
                className="group relative flex flex-col justify-between rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 transition-all hover:border-amber-500/50 hover:bg-zinc-900/90"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-code text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 border border-amber-900 px-2 py-0.5 rounded">
                      Planned Category
                    </span>
                    <span className="text-xs text-zinc-500 font-mono">v1.21.11 Spec</span>
                  </div>

                  <h3 className="font-cinzel text-xl font-bold text-white mt-3 flex items-center gap-2">
                    {cat.name === 'PvP' && <Swords className="h-5 w-5 text-red-400" />}
                    {cat.name === 'Building' && <Building2 className="h-5 w-5 text-amber-400" />}
                    {cat.name === 'Strategy' && <Brain className="h-5 w-5 text-purple-400" />}
                    
                    {cat.name === 'Economy' && <Coins className="h-5 w-5 text-emerald-400" />}
                    {cat.name === 'Influence' && <Sparkles className="h-5 w-5 text-cyan-400" />}
                    <span>{cat.name}</span>
                  </h3>

                  <p className="text-xs text-zinc-300 leading-relaxed mt-2">
                    {cat.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-zinc-800">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500 block mb-1.5">
                      Proposed Scoring Metrics:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {cat.metrics.map((metric, idx) => (
                        <span key={idx} className="rounded bg-zinc-800/80 px-2 py-0.5 text-[11px] text-zinc-300 font-mono">
                          {metric}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
                  <span className="text-xs text-zinc-500">Status: Prototype</span>
                  <button
                    onClick={() => handleVote(cat.name)}
                    className="rounded-lg border border-amber-500/40 bg-amber-950/40 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-900/60 hover:text-white transition-colors"
                  >
                    Vote for this First
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Community Input Box */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-6 sm:p-8">
        <div className="max-w-2xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400">
            <AlertCircle className="h-4 w-4" />
            <span>Community Input & Suggestions</span>
          </div>
          <h3 className="font-cinzel text-2xl font-bold text-white">
            Have an Idea for the Vengeance Tier List?
          </h3>
          <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
            What specific combat stats or building achievements should count toward rank placement? Send your ideas directly to our design board.
          </p>

          <form onSubmit={handleSuggest} className="flex flex-col sm:flex-row gap-3 pt-2">
            <input
              type="text"
              value={suggestedMetric}
              onChange={(e) => setSuggestedMetric(e.target.value)}
              placeholder="e.g. Include Trial Chamber Mace kill-streak multipliers..."
              className="flex-1 rounded-xl border border-zinc-800 bg-zinc-950 px-4 py-3 text-xs text-zinc-200 placeholder-zinc-500 focus:border-amber-500 focus:outline-none"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-600 px-5 py-3 text-xs font-bold text-white hover:bg-amber-500 active:scale-[0.98] transition-all"
            >
              {submittedFeedback ? (
                <>
                  <CheckCircle2 className="h-4 w-4 text-emerald-300" />
                  <span>Feedback Received!</span>
                </>
              ) : (
                <>
                  <Send className="h-3.5 w-3.5" />
                  <span>Submit Suggestion</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
