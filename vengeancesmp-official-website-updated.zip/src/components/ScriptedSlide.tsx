import React, { useState } from 'react';
import { 
  Heart, Skull, BookOpen, Quote, Shield, Flame, Compass, 
  MapPin, Sparkles, ChevronRight, Swords, AlertOctagon, 
  Users, Crown, Hammer, Crosshair, ExternalLink 
} from 'lucide-react';
import { 
  LORE_CHARACTERS, SCRIPT_EPISODES, 
  SCRIPTED_ROLES_INFO, SERVER_CONFIG 
} from '../data/serverData';
import { LoreCharacter, ScriptEpisode, ScriptedRoleCategory } from '../types';
import { sound } from '../utils/audio';

interface ScriptedSlideProps {
  onSelectEpisode: (episode: ScriptEpisode) => void;
  onTriggerUnderDevelopment?: (feature: string) => void;
}

export const ScriptedSlide: React.FC<ScriptedSlideProps> = ({ 
  onSelectEpisode,
  onTriggerUnderDevelopment 
}) => {
  // State for Canon Lives filter
  const [lifeFilter, setLifeFilter] = useState<'all' | 'alive' | 'critical' | 'fallen'>('all');
  
  // State for Roles filter
  const [selectedRoleCategory, setSelectedRoleCategory] = useState<ScriptedRoleCategory | 'All'>('All');

  // State for Seasons
  const [selectedSeason, setSelectedSeason] = useState<number>(3);

  // Filtered Lore Characters
  const filteredCharacters = LORE_CHARACTERS.filter((char) => {
    const matchesLife = 
      lifeFilter === 'all' || 
      (lifeFilter === 'alive' && char.canonLives >= 2) ||
      (lifeFilter === 'critical' && char.canonLives === 1) ||
      (lifeFilter === 'fallen' && char.canonLives === 0);

    const matchesRole = 
      selectedRoleCategory === 'All' || 
      char.roleCategory === selectedRoleCategory;

    return matchesLife && matchesRole;
  });

  // Filtered Episodes by Season
  const filteredEpisodes = SCRIPT_EPISODES.filter((ep) => {
    if (selectedSeason === 3) return ep.season === 3;
    if (selectedSeason === 2) return ep.season === 2;
    return ep.season === 1;
  });

  return (
    <div className="w-full space-y-20 pb-24">
      {/* ========================================================================= */}
      {/* HERO SECTION - SCRIPTED LORE                                              */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden border-b border-zinc-800 bg-zinc-950 pt-8 pb-16">
        {/* Cinematic Backdrop Image with Violet / Crimson Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/hero_scripted_lore_1790685306948.jpg"
            alt="Scripted Lore Ruined Castle"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-40 filter brightness-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-zinc-950/40" />
          <div className="absolute inset-0 bg-radial from-purple-950/30 via-transparent to-transparent" />
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/40 bg-purple-950/50 px-3 py-1 text-xs font-semibold text-purple-300">
              <Sparkles className="h-3.5 w-3.5 text-purple-400" />
              <span>SCRIPTED SMP · THE THEATRICAL REALM</span>
            </div>

            <h1 className="font-cinzel text-4xl font-extrabold tracking-tight text-white sm:text-6xl text-balance">
              The Scripted SMP
            </h1>

            <p className="text-base sm:text-lg text-zinc-300 leading-relaxed max-w-2xl">
              The Scripted SMP focuses on planned stories, memorable characters, mysteries, and major events. Step into an evolving narrative where every choice, discovery, and betrayal shapes the story.
            </p>

            {/* Quick Lore Navigation */}
            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs text-zinc-400">
              <span className="text-zinc-500 font-semibold uppercase tracking-wider">Explore:</span>
              <a href="#roles-section" className="hover:text-purple-400 transition-colors">Character Roles</a>
              <span>·</span>
              <a href="#canon-lives-section" className="hover:text-purple-400 transition-colors">3 Canon Lives Tracker</a>
              <span>·</span>
              <a href="#episodes-section" className="hover:text-purple-400 transition-colors">Script Episodes & Transcripts</a>
              <span>·</span>
              <a href="#characters-section" className="hover:text-purple-400 transition-colors">Main Characters</a>
            </div>
          </div>

          {/* Lore System Overview Card */}
          <div className="mt-10 rounded-2xl border border-purple-900/60 bg-zinc-900/90 p-5 shadow-2xl backdrop-blur-md">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-red-500/40 bg-red-950/60 text-red-400">
                  <Heart className="h-5 w-5 fill-red-500 text-red-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">3 Canon Lives</h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Every character carries 3 lives. Scripted deaths during canon events permanently extinguish a heart.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-purple-500/40 bg-purple-950/60 text-purple-400">
                  <BookOpen className="h-5 w-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Planned Storylines & Wars</h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Character rivalries, unexpected betrayals, and deep mysteries written into seasonal story chapters.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-amber-500/40 bg-amber-950/60 text-amber-400">
                  <Crown className="h-5 w-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Audition for Roles</h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Become a central protagonist, antagonist, kingdom architect, or battlefield champion.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION: ROLES YOU CAN BECOME (EXPLICIT USER PROMPT REQUIREMENT)           */}
      {/* ========================================================================= */}
      <section id="roles-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="border-b border-zinc-800 pb-5 mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
              <Users className="h-4 w-4" /> Casting & Archetypes
            </span>
            <h2 className="font-cinzel text-3xl font-bold text-white mt-1">
              What Players Can Become
            </h2>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl">
              Every citizen in the Scripted SMP occupies an essential role in the overarching theatrical storyline.
            </p>
          </div>

          <a
            href={SERVER_CONFIG.discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => sound.playLevelUp()}
            className="inline-flex items-center gap-2 rounded-xl bg-purple-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-purple-950 hover:bg-purple-500 transition-colors"
          >
            <span>Apply for Character Audition</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SCRIPTED_ROLES_INFO.map((roleInfo) => (
            <div
              key={roleInfo.category}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 flex flex-col justify-between hover:border-purple-500/50 hover:bg-zinc-900/90 transition-all group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${roleInfo.badgeColor}`}>
                    {roleInfo.category}
                  </span>
                  <span className="text-[11px] text-zinc-500 font-mono">{roleInfo.slots}</span>
                </div>

                <h3 className="font-cinzel text-xl font-bold text-white group-hover:text-purple-300 transition-colors">
                  {roleInfo.category}
                </h3>

                <p className="text-xs text-purple-400 font-semibold italic">
                  "{roleInfo.tagline}"
                </p>

                <p className="text-xs text-zinc-300 leading-relaxed">
                  {roleInfo.description}
                </p>

                <div className="pt-2">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500 block mb-1">
                    Role Focus:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {roleInfo.responsibilities.map((resp, idx) => (
                      <span key={idx} className="rounded bg-zinc-800/80 px-2 py-0.5 text-[10px] text-zinc-300">
                        • {resp}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
                <button
                  onClick={() => {
                    sound.playClick();
                    setSelectedRoleCategory(roleInfo.category);
                    const el = document.getElementById('canon-lives-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-xs text-purple-400 hover:text-white font-semibold flex items-center gap-1"
                >
                  <span>View Characters with this Role</span>
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 1: CANON LIVES TRACKER SYSTEM                                     */}
      {/* ========================================================================= */}
      <section id="canon-lives-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-zinc-800 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-400">
              <Heart className="h-4 w-4 fill-purple-500 text-purple-500" />
              <span>Life & Death Ledger</span>
            </div>
            <h2 className="font-cinzel text-3xl font-bold text-white mt-1">
              Canon Lives Status Tracker
            </h2>
            <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
              Track the 3 canon lives of our active cast. When all three hearts shatter, the character permanently falls into the Void.
            </p>
          </div>

          {/* Lives Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-lg">
            <button
              onClick={() => {
                sound.playClick();
                setLifeFilter('all');
                setSelectedRoleCategory('All');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                lifeFilter === 'all' && selectedRoleCategory === 'All' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              All Cast
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLifeFilter('alive');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                lifeFilter === 'alive' ? 'bg-emerald-600 text-white' : 'text-zinc-400 hover:text-emerald-300'
              }`}
            >
              Safe (2-3 Lives)
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLifeFilter('critical');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                lifeFilter === 'critical' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-red-300'
              }`}
            >
              Critical (1 Life Left)
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLifeFilter('fallen');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                lifeFilter === 'fallen' ? 'bg-zinc-700 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Fallen Spirits (0 Lives)
            </button>
          </div>
        </div>

        {/* Character Canon Cards */}
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredCharacters.map((char) => {
            const isCritical = char.canonLives === 1;
            const isFallen = char.canonLives === 0;

            return (
              <div
                key={char.id}
                className={`relative flex flex-col justify-between rounded-2xl border p-6 transition-all ${
                  isFallen
                    ? 'border-zinc-800 bg-zinc-950/80 opacity-75'
                    : isCritical
                    ? 'border-red-600/70 bg-gradient-to-b from-red-950/20 to-zinc-900 shadow-lg shadow-red-950/40 ring-1 ring-red-500/20'
                    : 'border-zinc-800 bg-zinc-900/60 hover:border-zinc-700'
                }`}
              >
                <div>
                  {/* Top Bar with Canon Hearts */}
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800">
                          {char.roleCategory}
                        </span>
                        <span className="text-[11px] text-zinc-500">{char.title}</span>
                      </div>
                      <h3 className="font-cinzel text-lg font-bold text-white flex items-center gap-1.5 mt-1">
                        {char.characterName}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                        <span>@{char.username}</span>
                        <span>·</span>
                        <span className="text-zinc-500">Vengeance SMP</span>
                      </div>
                    </div>

                    {/* Visual 3-Heart Counter */}
                    <div className="flex items-center gap-1 bg-zinc-950/80 px-2 py-1 rounded-lg border border-zinc-800">
                      {[1, 2, 3].map((heartIndex) => {
                        const hasLife = char.canonLives >= heartIndex;
                        return (
                          <Heart
                            key={heartIndex}
                            className={`h-4 w-4 ${
                              hasLife
                                ? isCritical
                                  ? 'fill-red-500 text-red-500 animate-pulse'
                                  : 'fill-red-500 text-red-500'
                                : 'text-zinc-700 fill-zinc-800'
                            }`}
                          />
                        );
                      })}
                    </div>
                  </div>

                  {/* Character Arc */}
                  <p className="mt-3 text-xs text-zinc-300 leading-relaxed">
                    {char.characterArc}
                  </p>

                  {/* Motive & Alignment */}
                  <div className="mt-3 rounded-lg border border-zinc-800/80 bg-zinc-950/40 p-2.5 space-y-1 text-xs">
                    <div>
                      <span className="text-zinc-500 block">Alignment:</span>
                      <span className="text-purple-300 font-semibold">{char.moralAlignment}</span>
                    </div>
                    <div>
                      <span className="text-zinc-500 block">Current Objective:</span>
                      <span className="text-zinc-300">{char.keyMotive}</span>
                    </div>
                  </div>

                  {/* Canon Deaths Record */}
                  <div className="mt-4 space-y-2">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 block flex items-center justify-between">
                      <span>Lost Canon Lives ({3 - char.canonLives}/3)</span>
                      {isCritical && <span className="text-red-400 font-bold">1 Life Remaining</span>}
                      {isFallen && <span className="text-zinc-500 font-bold">Permadeath</span>}
                    </span>

                    {char.deaths.length === 0 ? (
                      <div className="rounded border border-emerald-950/50 bg-emerald-950/20 p-2 text-[11px] text-emerald-400 font-semibold">
                        Unblemished. All 3 Canon Lives Intact.
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {char.deaths.map((death) => (
                          <div
                            key={death.lifeNumber}
                            className="rounded border border-zinc-800 bg-zinc-950/80 p-2 text-xs space-y-0.5"
                          >
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-bold text-red-400">Heart #{death.lifeNumber} Lost</span>
                              <span className="text-zinc-500">Ep. {death.episodeNumber}</span>
                            </div>
                            <p className="text-zinc-300 text-[11px]">
                              <span className="text-zinc-500">Slayer:</span> {death.killer} · <span className="text-zinc-500">Cause:</span> {death.cause}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Signature Artifact */}
                <div className="mt-4 pt-3 border-t border-zinc-800/80 text-xs">
                  <span className="text-zinc-500 block text-[11px]">Signature Artifact:</span>
                  <span className="font-semibold text-amber-300 flex items-center gap-1 mt-0.5">
                    <Sparkles className="h-3.5 w-3.5" /> {char.signatureArtifact}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 2: CHRONICLE EPISODES & SCRIPT ARCHIVES                           */}
      {/* ========================================================================= */}
      <section id="episodes-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-zinc-800 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-400">
              <BookOpen className="h-4 w-4" />
              <span>Official Story Archives</span>
            </div>
            <h2 className="font-cinzel text-3xl font-bold text-white mt-1">
              Script Episodes & Story Timeline
            </h2>
            <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
              Delve into the official episode recaps, pivotal turning points, and dialogue transcripts written for each canon broadcast.
            </p>
          </div>

          {/* Season Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-lg">
            <button
              onClick={() => {
                sound.playClick();
                setSelectedSeason(3);
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                selectedSeason === 3 ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Season 3: The Deepslate (Current)
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setSelectedSeason(2);
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                selectedSeason === 2 ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Season 2: The Obsidian War
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setSelectedSeason(1);
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                selectedSeason === 1 ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Season 1: The Broken Crown
            </button>
          </div>
        </div>

        {/* Episodes Grid */}
        <div className="mt-8 space-y-6">
          {filteredEpisodes.map((episode) => (
            <div
              key={episode.id}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 transition-all hover:border-zinc-700 hover:bg-zinc-900/90"
            >
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
                {/* Left Info */}
                <div className="space-y-3 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-code text-xs font-bold text-purple-400 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800">
                      S{episode.season} · EPISODE {episode.episodeNumber}
                    </span>
                    <span className="text-xs text-zinc-500 font-semibold uppercase tracking-wider">
                      Official Canon Broadcast
                    </span>
                  </div>

                  <h3 className="font-cinzel text-2xl font-bold text-white">
                    {episode.title}
                  </h3>

                  <p className="text-sm text-zinc-300 leading-relaxed max-w-3xl">
                    {episode.synopsis}
                  </p>

                  {/* Dramatic Quote Box */}
                  <div className="rounded-lg border-l-4 border-purple-500 bg-zinc-950/80 p-3 italic text-xs text-purple-200 flex items-start gap-2">
                    <Quote className="h-4 w-4 shrink-0 text-purple-400 mt-0.5" />
                    <div>
                      <span className="font-bold">{episode.speaker}: </span>"{episode.keyQuote}"
                    </div>
                  </div>

                  {/* Key Highlights */}
                  <div className="pt-2 flex flex-wrap gap-2 text-xs">
                    {episode.keyMoments.map((moment, idx) => (
                      <span key={idx} className="rounded bg-zinc-800/80 px-2.5 py-1 text-zinc-300">
                        {moment}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Right Action: Read Script Excerpt */}
                <div className="shrink-0 flex flex-col justify-between items-start lg:items-end gap-4 border-t lg:border-t-0 lg:border-l border-zinc-800 pt-4 lg:pt-0 lg:pl-6">
                  <div className="text-xs text-zinc-400 space-y-1">
                    <span className="text-zinc-500 block">Canon Ramifications:</span>
                    <ul className="list-disc list-inside space-y-0.5 text-red-300">
                      {episode.canonEvents.map((evt, idx) => (
                        <li key={idx}>{evt}</li>
                      ))}
                    </ul>
                  </div>

                  <button
                    onClick={() => {
                      sound.playClick();
                      onSelectEpisode(episode);
                    }}
                    className="flex items-center gap-2 rounded-xl bg-purple-600 px-4 py-2.5 text-xs font-semibold text-white shadow-lg shadow-purple-950 transition-all hover:bg-purple-500 hover:shadow-purple-900 active:scale-[0.98]"
                  >
                    <BookOpen className="h-4 w-4" />
                    <span>Read Script Excerpt</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Character-focused closing section */}
      <section id="characters-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-2xl border border-zinc-800 bg-gradient-to-r from-red-950/30 via-zinc-900 to-purple-950/20 p-6 sm:p-8">
          <span className="text-xs font-semibold uppercase tracking-wider text-red-400">Story first</span>
          <h2 className="mt-1 font-cinzel text-3xl font-bold text-white">A World Driven by Characters</h2>
          <p className="mt-3 max-w-3xl text-sm leading-relaxed text-zinc-300">Vengeance follows the choices, rivalries, discoveries, and consequences of its players. The story is about the people who shape it—not group rosters or territory charts.</p>
          <a href="https://discord.gg/WX9rFvHhTb" target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-red-500">Join the community <ExternalLink className="h-3.5 w-3.5" /></a>
        </div>
      </section>
    </div>
  );
};
