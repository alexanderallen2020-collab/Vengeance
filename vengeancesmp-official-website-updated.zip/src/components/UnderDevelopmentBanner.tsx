import React, { useEffect, useState } from 'react';
import { Hammer, Sparkles, X, Clock } from 'lucide-react';
import { sound } from '../utils/audio';

interface UnderDevelopmentBannerProps {
  message?: string;
  featureName?: string;
  isOpen: boolean;
  onClose: () => void;
}

export const UnderDevelopmentBanner: React.FC<UnderDevelopmentBannerProps> = ({
  message = 'This feature is currently in active development.',
  featureName = 'UNDER DEVELOPMENT',
  isOpen,
  onClose
}) => {
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    if (!isOpen) {
      setProgress(100);
      return;
    }

    sound.playToll();
    const startTime = Date.now();
    const duration = 2000; // 2 seconds as requested

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 100 - (elapsed / duration) * 100);
      setProgress(remaining);

      if (elapsed >= duration) {
        clearInterval(interval);
        onClose();
      }
    }, 20);

    return () => clearInterval(interval);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed top-20 left-1/2 z-50 -translate-x-1/2 px-4 w-full max-w-md pointer-events-auto animate-in fade-in slide-in-from-top-4 duration-200">
      <div className="relative overflow-hidden rounded-xl border-2 border-amber-500/80 bg-zinc-950/95 p-4 shadow-2xl shadow-amber-950/60 backdrop-blur-md">
        {/* Glow accent */}
        <div className="absolute -top-12 left-1/2 h-24 w-48 -translate-x-1/2 bg-amber-500/20 blur-2xl" />

        <div className="relative flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-amber-500/50 bg-amber-950/70 text-amber-400 shadow-inner">
              <Hammer className="h-5 w-5 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-cinzel text-sm font-extrabold tracking-widest text-amber-400">
                  UNDER DEVELOPMENT
                </span>
                <span className="flex h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping" />
              </div>
              <p className="mt-1 text-xs text-zinc-300">
                {message}
              </p>
              <div className="mt-1 flex items-center gap-1 text-[11px] text-zinc-500">
                <Clock className="h-3 w-3" />
                <span>Auto-dismissing in 2 seconds</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="flex h-6 w-6 items-center justify-center rounded border border-zinc-700 bg-zinc-900 text-zinc-400 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* 2-second Progress Bar */}
        <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-zinc-800">
          <div
            className="h-full bg-amber-500 transition-all ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
};
