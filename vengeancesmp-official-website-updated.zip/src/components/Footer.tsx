import React, { useState } from 'react';
import { Copy, Check, ExternalLink, ArrowUp } from 'lucide-react';
import { SERVER_CONFIG } from '../data/serverData';
import { PageView } from '../types';
import { sound } from '../utils/audio';

interface FooterProps {
  onNavigate?: (page: PageView) => void;
  onTriggerUnderDevelopment?: (feature: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ 
  onNavigate,
  onTriggerUnderDevelopment 
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyIp = () => {
    sound.playLevelUp();
    navigator.clipboard.writeText(SERVER_CONFIG.ip);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const scrollToTop = () => {
    sound.playClick();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLink = (page: PageView) => {
    sound.playClick();
    if (onNavigate) {
      if (page === 'tier-list' && onTriggerUnderDevelopment) {
        onNavigate('tier-list');
        onTriggerUnderDevelopment('Tier List ranking engine is currently in active calibration.');
        return;
      }
      onNavigate(page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <footer className="border-t border-zinc-800 bg-zinc-950 text-zinc-400 text-xs">
      {/* Large Discord Prompt (Prompt Required) */}
      <div className="border-b border-zinc-900 bg-gradient-to-b from-zinc-950 to-indigo-950/20 py-16 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto space-y-4">
          <h3 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white">
            Join Vengeance<span className="text-red-500">.</span>
          </h3>
          <p className="font-cinzel text-base sm:text-xl font-bold tracking-wide text-zinc-300">
            Your story. Your choices. Your legacy.
          </p>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-lg mx-auto leading-relaxed">
            The gates are open. Join thousands of players, form alliances, participate in war councils, and begin carving your legacy into the world.
          </p>
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href={SERVER_CONFIG.discordUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => sound.playLevelUp()}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-8 py-3.5 text-sm font-extrabold text-white shadow-xl shadow-indigo-950 hover:bg-indigo-500 active:scale-[0.98] transition-all"
            >
              <span>JOIN DISCORD</span>
              <ExternalLink className="h-4 w-4" />
            </a>

            <button
              onClick={handleCopyIp}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 px-6 py-3.5 text-xs font-semibold text-zinc-300 hover:text-white"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'IP Copied!' : `Copy IP: ${SERVER_CONFIG.ip}`}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          {/* Brand & Summary */}
          <div className="space-y-3 md:col-span-2">
            <span className="font-cinzel text-xl font-bold tracking-wider text-red-500">
              VENGEANCE<span className="text-zinc-100">.</span>
            </span>
            <p className="text-zinc-400 text-xs max-w-sm leading-relaxed">
              Vengeance is a Minecraft SMP built around player-driven stories, events, mysteries, and exploration. Version 1.21.11 Java.
            </p>
            <div className="flex items-center gap-2 pt-1 font-code text-zinc-300">
              <span>{SERVER_CONFIG.ip}</span>
              <button
                onClick={handleCopyIp}
                className="text-[11px] text-red-400 hover:text-red-300 font-semibold"
              >
                {copied ? 'Copied' : 'Copy IP'}
              </button>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-2">
            <h4 className="font-semibold text-zinc-200 uppercase tracking-wider text-[11px]">
              Main Sections
            </h4>
            <ul className="space-y-1.5 text-zinc-400">
              <li>
                <button onClick={() => handleLink('home')} className="hover:text-zinc-200 transition-colors">Home</button>
              </li>
              <li>
                <button onClick={() => handleLink('scripted')} className="hover:text-zinc-200 transition-colors">Scripted SMP</button>
              </li>
              <li>
                <button onClick={() => handleLink('unscripted')} className="hover:text-zinc-200 transition-colors">Unscripted SMP</button>
              </li>
              <li>
                <button onClick={() => handleLink('tier-list')} className="hover:text-zinc-200 transition-colors">Tier List</button>
              </li>
              <li>
                <button onClick={() => handleLink('promotion')} className="hover:text-zinc-200 transition-colors">Promotion</button>
              </li>
            </ul>
          </div>

          {/* Server Resources */}
          <div className="space-y-2">
            <h4 className="font-semibold text-zinc-200 uppercase tracking-wider text-[11px]">
              Server Resources
            </h4>
            <ul className="space-y-1.5 text-zinc-400">
              <li>
                <button onClick={() => handleLink('rules')} className="hover:text-zinc-200 transition-colors">Server Rules</button>
              </li>
              <li>
                <button onClick={() => handleLink('about')} className="hover:text-zinc-200 transition-colors">About Vengeance</button>
              </li>
              <li>
                <button onClick={() => handleLink('events')} className="hover:text-zinc-200 transition-colors">Events</button>
              </li>
              <li>
                <button onClick={() => handleLink('faq')} className="hover:text-zinc-200 transition-colors">FAQ</button>
              </li>
              <li>
                <button onClick={scrollToTop} className="hover:text-zinc-200 transition-colors flex items-center gap-1">
                  <ArrowUp className="h-3 w-3" /> Back to Top
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 border-t border-zinc-900 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-500">
          <p>© {new Date().getFullYear()} Vengeance. Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.</p>
          <div className="flex items-center gap-4">
            <span>Java & Bedrock Port 25565</span>
            <span>·</span>
            <span>Version {SERVER_CONFIG.version}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
