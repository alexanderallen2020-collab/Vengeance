import React, { useState } from 'react';
import { X, Mail, Send, CheckCircle2, MessageSquare, Shield, HelpCircle } from 'lucide-react';
import { sound } from '../utils/audio';
import { SERVER_CONFIG } from '../data/serverData';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    ign: '',
    discordTag: '',
    category: 'General Inquiry',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.ign.trim() || !formData.message.trim()) return;
    sound.playLevelUp();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ ign: '', discordTag: '', category: 'General Inquiry', message: '' });
      onClose();
    }, 2500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={() => {
        sound.playClick();
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-zinc-700 bg-zinc-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative border-b border-zinc-800 bg-gradient-to-r from-red-950 via-zinc-900 to-zinc-950 p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-red-400">
                <Mail className="h-3.5 w-3.5" />
                <span>Vengeance Support & Communications</span>
              </div>
              <h2 className="font-cinzel text-2xl font-bold text-white mt-1">Contact Staff & Council</h2>
              <p className="text-xs text-zinc-400 mt-1">
                Have a partnership proposal, bug report, or general question? Submit a ticket directly.
              </p>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Content Form */}
        <div className="p-6">
          {submitted ? (
            <div className="py-8 text-center space-y-3">
              <CheckCircle2 className="h-12 w-12 text-emerald-400 mx-auto animate-bounce" />
              <h3 className="font-cinzel text-xl font-bold text-white">Ticket Dispatched</h3>
              <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                Your message has been forwarded to the server administrators and moderator channels.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-zinc-400 font-semibold block mb-1">
                    Minecraft Username <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.ign}
                    onChange={(e) => setFormData({ ...formData, ign: e.target.value })}
                    placeholder="e.g. KryoVex"
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-zinc-200 placeholder-zinc-600 focus:border-red-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-zinc-400 font-semibold block mb-1">
                    Discord Tag (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.discordTag}
                    onChange={(e) => setFormData({ ...formData, discordTag: e.target.value })}
                    placeholder="e.g. user#1234 or @user"
                    className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-zinc-200 placeholder-zinc-600 focus:border-red-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-zinc-400 font-semibold block mb-1">Inquiry Type</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-zinc-200 focus:border-red-500 focus:outline-none"
                >
                  <option value="General Inquiry">General Inquiry</option>
                  <option value="Content Creator / Media Partnership">Content Creator / Media Partnership</option>
                  <option value="Cross-Community Alliance">Cross-Community Alliance</option>
                  <option value="Rule Violation / Exploit Report">Rule Violation / Exploit Report</option>
                  <option value="Server Suggestion">Server Suggestion</option>
                </select>
              </div>

              <div>
                <label className="text-zinc-400 font-semibold block mb-1">
                  Message Details <span className="text-red-400">*</span>
                </label>
                <textarea
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Describe your inquiry, proposal, or question in detail..."
                  className="w-full rounded-xl border border-zinc-800 bg-zinc-950 p-3 text-zinc-200 placeholder-zinc-600 focus:border-red-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                <span className="text-[11px] text-zinc-500">
                  Direct Discord tickets also available in{' '}
                  <a
                    href={SERVER_CONFIG.discordUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-400 underline"
                  >
                    #support
                  </a>
                </span>

                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 rounded-xl bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-500 transition-colors"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Send Message</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
