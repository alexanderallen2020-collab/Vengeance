import React, { useState } from 'react';
import { 
  Shield, Info, Calendar, Newspaper, HelpCircle, 
  UserCheck, Search, ChevronDown, ChevronUp, Check, 
  AlertTriangle, ExternalLink, Mail, Clock, MapPin 
} from 'lucide-react';
import { 
  SERVER_RULES, SERVER_EVENTS, NEWS_POSTS, 
  FAQ_ITEMS, STAFF_MEMBERS, SERVER_CONFIG 
} from '../data/serverData';
import { PageView } from '../types';
import { sound } from '../utils/audio';

interface ExtraPagesProps {
  view: PageView;
  onNavigate: (page: PageView) => void;
  onOpenContact: () => void;
  onTriggerUnderDevelopment: (feature: string) => void;
}

export const ExtraPages: React.FC<ExtraPagesProps> = ({
  view,
  onNavigate,
  onOpenContact,
  onTriggerUnderDevelopment
}) => {
  // State for FAQ accordion
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // State for Rules
  const [ruleSearch, setRuleSearch] = useState('');
  const [selectedRuleCategory, setSelectedRuleCategory] = useState<string>('All');
  const [expandedRuleId, setExpandedRuleId] = useState<string | null>('rule-1');

  // Filter Rules
  const filteredRules = SERVER_RULES.filter((rule) => {
    const matchesCategory = selectedRuleCategory === 'All' || rule.category === selectedRuleCategory;
    const q = ruleSearch.toLowerCase();
    const matchesSearch = 
      rule.title.toLowerCase().includes(q) ||
      rule.shortDescription.toLowerCase().includes(q) ||
      rule.fullRule.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* ========================================================================= */}
      {/* 1. RULES PAGE                                                             */}
      {/* ========================================================================= */}
      {view === 'rules' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-zinc-800 pb-5">
            <span className="text-xs font-semibold uppercase tracking-wider text-red-400 flex items-center gap-1.5">
              <Shield className="h-4 w-4" /> Server Enforcement
            </span>
            <h1 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white mt-1">
              Official Server Rules
            </h1>
            <p className="text-sm text-zinc-400 mt-2 max-w-2xl">
              Vengeance operates on a vanilla+ hardcore ethos. Review the code of conduct before setting foot outside spawn.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-lg">
            {['All', 'Combat & PvP', 'Exploits & Fair Play', 'Raiding & Griefing', 'Economy & Trading', 'Community Conduct'].map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  sound.playClick();
                  setSelectedRuleCategory(cat);
                }}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                  selectedRuleCategory === cat
                    ? 'bg-red-600 text-white'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input
              type="text"
              value={ruleSearch}
              onChange={(e) => setRuleSearch(e.target.value)}
              placeholder="Search rule keywords..."
              className="w-full rounded-xl border border-zinc-800 bg-zinc-900/80 pl-10 pr-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:border-red-500 focus:outline-none"
            />
          </div>

          {/* Rules List */}
          <div className="space-y-3">
            {filteredRules.map((rule) => {
              const isExpanded = expandedRuleId === rule.id;
              return (
                <div
                  key={rule.id}
                  className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden"
                >
                  <button
                    onClick={() => {
                      sound.playClick();
                      setExpandedRuleId(isExpanded ? null : rule.id);
                    }}
                    className="w-full flex items-center justify-between p-4 sm:p-5 text-left hover:bg-zinc-800/40 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 font-code text-xs font-bold text-red-400">
                        #{rule.number}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-zinc-400 font-semibold">{rule.category}</span>
                          <span className="text-zinc-600">·</span>
                          <span className="text-red-400 font-semibold">Penalty: {rule.penalty}</span>
                        </div>
                        <h3 className="font-semibold text-zinc-100 text-sm sm:text-base mt-0.5">
                          {rule.title}
                        </h3>
                      </div>
                    </div>
                    {isExpanded ? <ChevronUp className="h-5 w-5 text-zinc-400" /> : <ChevronDown className="h-5 w-5 text-zinc-400" />}
                  </button>

                  {isExpanded && (
                    <div className="border-t border-zinc-800 bg-zinc-950/60 p-5 space-y-4 text-xs">
                      <p className="text-zinc-300 leading-relaxed text-sm">{rule.fullRule}</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        <div className="rounded-lg border border-emerald-950/60 bg-emerald-950/20 p-3">
                          <span className="font-semibold text-emerald-400 flex items-center gap-1.5 mb-2">
                            <Check className="h-4 w-4" /> Permitted Actions
                          </span>
                          <ul className="space-y-1 text-zinc-300">
                            {rule.examplesAllowed.map((ex, i) => (
                              <li key={i}>• {ex}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="rounded-lg border border-red-950/60 bg-red-950/20 p-3">
                          <span className="font-semibold text-red-400 flex items-center gap-1.5 mb-2">
                            <AlertTriangle className="h-4 w-4" /> Prohibited Violations
                          </span>
                          <ul className="space-y-1 text-zinc-300">
                            {rule.examplesProhibited.map((ex, i) => (
                              <li key={i}>• {ex}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ABOUT PAGE                                                             */}
      {/* ========================================================================= */}
      {view === 'about' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-zinc-800 pb-5">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
              <Info className="h-4 w-4" /> History & Philosophy
            </span>
            <h1 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white mt-1">
              About Vengeance
            </h1>
            <p className="text-sm text-zinc-400 mt-2 max-w-2xl">
              Built by passionate Minecraft players for those who crave meaningful stakes, deep roleplay, and genuine survival community.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 space-y-4">
              <h3 className="font-cinzel text-xl font-bold text-white">The Core Vision</h3>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                Vengeance is built around memorable player stories, lasting consequences, exploration, and meaningful community events.
              </p>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                Whether you prefer building quiet mountain sanctuaries or commanding frontline legions in the Bedrock Basin, your actions leave a permanent mark on our history.
              </p>
            </div>

            <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 space-y-4">
              <h3 className="font-cinzel text-xl font-bold text-white">Technical Infrastructure</h3>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                Running on custom dedicated hardware optimized for 1.21.11, Vengeance maintains a rock-solid 20.0 TPS with enterprise anti-cheat protection. We seamlessly bridge Java and Bedrock editions so players across PC, consoles, and mobile devices can share the same battlefield.
              </p>
              <div className="pt-2 text-xs space-y-1 font-code text-zinc-400">
                <div>Server IP: <span className="text-zinc-200">{SERVER_CONFIG.ip}</span></div>
                <div>Default Port: <span className="text-zinc-200">{SERVER_CONFIG.port}</span></div>
                <div>Server Location: North America & Global Routing</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. EVENTS PAGE                                                            */}
      {/* ========================================================================= */}
      {view === 'events' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-zinc-800 pb-5">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Calendar className="h-4 w-4" /> Server Schedule
            </span>
            <h1 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white mt-1">
              Events & Summits
            </h1>
            <p className="text-sm text-zinc-400 mt-2 max-w-2xl">
              Major story milestones, unscripted survival launches, and community tournaments.
            </p>
          </div>

          <div className="space-y-4">
            {SERVER_EVENTS.map((event) => (
              <div
                key={event.id}
                className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="font-code text-[11px] font-bold uppercase text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800">
                      {event.type}
                    </span>
                    <span className={`text-[11px] font-semibold ${event.status === 'Upcoming' ? 'text-emerald-400' : 'text-zinc-500'}`}>
                      • {event.status}
                    </span>
                  </div>
                  <h3 className="font-cinzel text-xl font-bold text-white">{event.title}</h3>
                  <p className="text-xs sm:text-sm text-zinc-300">{event.description}</p>
                  <div className="flex items-center gap-4 text-xs text-zinc-400 pt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5 text-zinc-500" /> {event.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5 text-zinc-500" /> {event.location}
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  <a
                    href={SERVER_CONFIG.discordUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-2 text-xs font-semibold text-zinc-200 hover:text-white hover:border-amber-500 transition-colors"
                  >
                    <span>RSVP on Discord</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. NEWS PAGE                                                              */}
      {/* ========================================================================= */}
      {view === 'news' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-zinc-800 pb-5">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
              <Newspaper className="h-4 w-4" /> Bulletin & Changelogs
            </span>
            <h1 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white mt-1">
              News & Updates
            </h1>
            <p className="text-sm text-zinc-400 mt-2 max-w-2xl">
              Latest patch notes, balance adjustments, and creator updates.
            </p>
          </div>

          <div className="space-y-6">
            {NEWS_POSTS.map((post) => (
              <div
                key={post.id}
                className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 space-y-3"
              >
                <div className="flex items-center justify-between text-xs text-zinc-500">
                  <span className="font-code font-bold text-purple-400 uppercase">{post.tag}</span>
                  <span>{post.date}</span>
                </div>
                <h3 className="font-cinzel text-2xl font-bold text-white">{post.title}</h3>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">{post.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. FAQ PAGE                                                               */}
      {/* ========================================================================= */}
      {view === 'faq' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-zinc-800 pb-5">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <HelpCircle className="h-4 w-4" /> Player Knowledgebase
            </span>
            <h1 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white mt-1">
              Frequently Asked Questions
            </h1>
            <p className="text-sm text-zinc-400 mt-2 max-w-2xl">
              Everything you need to know about joining, recording, and auditioning for Vengeance.
            </p>
          </div>

          <div className="space-y-3">
            {FAQ_ITEMS.map((item, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden"
                >
                  <button
                    onClick={() => {
                      sound.playClick();
                      setOpenFaqIndex(isOpen ? null : idx);
                    }}
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-zinc-800/40 transition-colors"
                  >
                    <span className="font-semibold text-zinc-100 text-sm sm:text-base">{item.question}</span>
                    {isOpen ? <ChevronUp className="h-5 w-5 text-zinc-400" /> : <ChevronDown className="h-5 w-5 text-zinc-400" />}
                  </button>
                  {isOpen && (
                    <div className="border-t border-zinc-800 bg-zinc-950/60 p-5 text-xs sm:text-sm text-zinc-300 leading-relaxed">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. STAFF PAGE                                                             */}
      {/* ========================================================================= */}
      {view === 'staff' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="border-b border-zinc-800 pb-5 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                <UserCheck className="h-4 w-4" /> Server Administration
              </span>
              <h1 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white mt-1">
                Staff & Council
              </h1>
              <p className="text-sm text-zinc-400 mt-2 max-w-2xl">
                The developers, story coordinators, and anticheat engineers keeping Vengeance running.
              </p>
            </div>
            <button
              onClick={() => onTriggerUnderDevelopment('Staff applications are scheduled to open next month.')}
              className="rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-2 text-xs font-semibold text-zinc-300 hover:text-white"
            >
              Apply for Staff
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {STAFF_MEMBERS.map((staff, idx) => (
              <div
                key={idx}
                className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5 flex items-center gap-4"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-zinc-700 bg-zinc-800 font-cinzel text-lg font-bold text-cyan-400">
                  {staff.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">{staff.name}</h4>
                  <p className="text-xs text-cyan-400">{staff.role}</p>
                  <span className="text-[11px] text-zinc-500 font-mono mt-0.5 block">• {staff.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
