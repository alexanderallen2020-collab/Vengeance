import React from 'react';
import { 
  Swords, Scroll, Trophy, Users, Shield, ArrowRight, 
  Sparkles, Flame, Compass, ExternalLink, Calendar, Check 
} from 'lucide-react';
import { ServerStatusCard } from './ServerStatusCard';
import { SERVER_CONFIG } from '../data/serverData';
import { PageView } from '../types';
import { sound } from '../utils/audio';

interface HomePageProps {
  onNavigate: (page: PageView) => void;
  onTriggerUnderDevelopment: (feature: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onTriggerUnderDevelopment
}) => {
  return (
    <div className="w-full space-y-24 pb-20">
      {/* ========================================================================= */}
      {/* HERO SECTION                                                             */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden border-b border-zinc-800/80 bg-zinc-950 pt-16 pb-20 sm:pt-24 sm:pb-28">
        {/* Cinematic Backdrop Image */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/hero_unscripted_smp_1790685293657.jpg"
            alt="Vengeance Minecraft Fortress"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-35 filter brightness-70"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/75 to-zinc-950/40" />
          <div className="absolute inset-0 bg-radial from-red-950/20 via-transparent to-transparent" />
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-6">
            {/* Server Badge */}
            <div className="inline-flex items-center gap-2 rounded-full border border-red-500/30 bg-red-950/40 px-3.5 py-1 text-xs font-semibold text-red-300">
              <span className="flex h-2 w-2 rounded-full bg-red-500 animate-ping" />
              <span>MINECRAFT 1.21.11 SMP</span>
            </div>

            {/* Prompt Required Introduction */}
            <div>
              <h1 className="font-cinzel text-5xl font-extrabold tracking-tight text-white sm:text-7xl lg:text-8xl">
                Vengeance<span className="text-red-500">.</span>
              </h1>
              <p className="mt-3 font-cinzel text-xl sm:text-2xl font-bold tracking-wide text-zinc-200">
                Your story. Your choices. Your legacy.
              </p>
            </div>

            <p className="text-base sm:text-lg text-zinc-300 leading-relaxed max-w-2xl">
              Vengeance is a cinematic Minecraft SMP built around player-driven stories, scripted and unscripted adventures, mysteries, and community-made videos.
            </p>

            {/* Required Action Buttons: Explore Vengeance & Join Discord */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => {
                  sound.playClick();
                  const el = document.getElementById('modes-overview');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-red-600 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-red-950 transition-all hover:bg-red-500 hover:shadow-red-900 active:scale-[0.98]"
              >
                <span>Explore Vengeance</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              <a
                href={SERVER_CONFIG.discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => sound.playLevelUp()}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-indigo-500/50 bg-indigo-600/90 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-indigo-950 transition-all hover:bg-indigo-500 active:scale-[0.98]"
              >
                <span>Join Discord</span>
                <ExternalLink className="h-4 w-4 opacity-80" />
              </a>

              <button
                onClick={() => {
                  sound.playClick();
                  onNavigate('tier-list');
                  onTriggerUnderDevelopment('Tier List ranking engine is currently in active calibration.');
                }}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900/80 px-4 py-3.5 text-sm font-semibold text-zinc-300 hover:border-zinc-700 hover:text-white"
              >
                <Trophy className="h-4 w-4 text-amber-400" />
                <span>Tier List</span>
              </button>
            </div>
          </div>

          {/* Real-time Server Connection Box */}
          <div className="mt-12">
            <ServerStatusCard />
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* THE TWO REALMS: SCRIPTED VS UNSCRIPTED                                    */}
      {/* ========================================================================= */}
      <section id="modes-overview" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-red-400">
            Dual Server Ecosystem
          </span>
          <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-white">
            Choose Your Vengeance Experience
          </h2>
          <p className="text-sm text-zinc-400">
            Vengeance hosts two distinct gameplay experiences: a continuous theatrical lore universe and high-intensity temporary survival sprints.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
          {/* Card 1: Scripted SMP */}
          <div className="relative overflow-hidden rounded-2xl border border-purple-900/60 bg-gradient-to-b from-purple-950/20 to-zinc-900/90 p-8 flex flex-col justify-between shadow-xl">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-code text-xs font-bold text-purple-400 uppercase tracking-widest bg-purple-950/80 border border-purple-800 px-2.5 py-1 rounded">
                  Storyline Universe
                </span>
                <span className="text-xs text-zinc-400">3 Canon Lives</span>
              </div>

              <h3 className="font-cinzel text-3xl font-bold text-white">
                Scripted SMP
              </h3>

              <p className="text-sm text-zinc-300 leading-relaxed">
                The Scripted SMP focuses on planned stories, memorable characters, mysteries, and major events. Step into a cinematic roleplay world where decisions shape the story.
              </p>

              <div className="pt-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500 block mb-2">
                  Key Roles You Can Become:
                </span>
                <div className="flex flex-wrap gap-2 text-xs">
                  {['Main Characters', 'Important Characters', 'Side Characters', 'Antagonists', 'Builders', 'PvPers'].map((role) => (
                    <span key={role} className="rounded bg-purple-950/60 border border-purple-900/80 px-2.5 py-1 text-purple-200">
                      {role}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-purple-900/40 flex items-center justify-between">
              <span className="text-xs text-zinc-400">Season 3: The Deepslate Arc</span>
              <button
                onClick={() => {
                  sound.playClick();
                  onNavigate('scripted');
                }}
                className="inline-flex items-center gap-1.5 rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-purple-950 hover:bg-purple-500 transition-colors"
              >
                <span>Explore Scripted SMP</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Card 2: Unscripted SMP */}
          <div className="relative overflow-hidden rounded-2xl border border-red-900/60 bg-gradient-to-b from-red-950/20 to-zinc-900/90 p-8 flex flex-col justify-between shadow-xl">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-code text-xs font-bold text-red-400 uppercase tracking-widest bg-red-950/80 border border-red-800 px-2.5 py-1 rounded">
                  Every Few Weeks
                </span>
                <span className="text-xs text-zinc-400">Full POV Recording</span>
              </div>

              <h3 className="font-cinzel text-3xl font-bold text-white">
                Unscripted SMP
              </h3>

              <p className="text-sm text-zinc-300 leading-relaxed">
                The Unscripted SMP is a separate temporary server hosted every few weeks. There is no planned storyline. Players create their own stories through building, PvP, rivalries, exploration, and survival. Everyone is allowed to record their own POV.
              </p>

              <div className="pt-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500 block mb-2">
                  Core Gameplay Loop:
                </span>
                <div className="flex flex-wrap gap-2 text-xs">
                  {['Unscripted Survival', 'Player Rivalries', 'Community Events', 'Creator POVs'].map((tag) => (
                    <span key={tag} className="rounded bg-red-950/60 border border-red-900/80 px-2.5 py-1 text-red-200">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-red-900/40 flex items-center justify-between">
              <span className="text-xs text-zinc-400">Sprint 4 Launching Soon</span>
              <button
                onClick={() => {
                  sound.playClick();
                  onNavigate('unscripted');
                }}
                className="inline-flex items-center gap-1.5 rounded-xl bg-red-600 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-red-950 hover:bg-red-500 transition-colors"
              >
                <span>Learn About Unscripted SMP</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* MAIN CHARACTERS                                                        */}
      {/* ========================================================================= */}
      <section id="main-characters" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 border-b border-zinc-800 pb-5">
          <span className="text-xs font-semibold uppercase tracking-wider text-red-400">The Faces of Vengeance</span>
          <h2 className="mt-1 font-cinzel text-3xl font-bold text-white sm:text-4xl">Main Characters</h2>
          <p className="mt-2 max-w-2xl text-sm text-zinc-400">The creators and players at the center of the story. Choose a name to find their YouTube channel.</p>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {[
            { name: 'JstWrxth', number: '01', channel: 'https://youtube.com/@ignjstwrxth', channelLabel: '@ignjstwrxth', avatar: 'https://unavatar.io/youtube/ignjstwrxth' },
            { name: 'ItzSwiftonic', number: '02', channel: 'https://youtube.com/@ignitzswiftonic', channelLabel: '@ignitzswiftonic', avatar: 'https://unavatar.io/youtube/ignitzswiftonic' },
            { name: 'Kyron', number: '03', channel: 'https://youtube.com/@kryon-c5m', channelLabel: '@kryon-c5m', avatar: 'https://unavatar.io/youtube/kryon-c5m' },
            { name: 'Kingcoolcat', number: '04', channel: 'https://www.youtube.com/results?search_query=Kingcoolcat', channelLabel: 'Channel unavailable', avatar: null },
            { name: 'EvolutionBattle', number: '05', channel: 'https://youtube.com/@evolutionbattleyt', channelLabel: '@evolutionbattleyt', avatar: 'https://unavatar.io/youtube/evolutionbattleyt' },
          ].map((character) => (
            <article key={character.name} className="group relative overflow-hidden rounded-2xl border border-zinc-800 bg-gradient-to-b from-zinc-900 to-zinc-950 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-red-500/60 hover:shadow-xl hover:shadow-red-950/20">
              <div className="mb-5 flex items-center justify-between">
                <span className="font-code text-xs text-red-400">CHARACTER {character.number}</span>
                <span className="h-2 w-2 rounded-full bg-red-500 shadow-[0_0_12px_rgba(239,68,68,0.8)]" />
              </div>
              <div className="mb-5 flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl border border-red-500/40 bg-red-950/40 font-cinzel text-2xl font-bold text-red-300 shadow-lg shadow-red-950/20 transition-colors group-hover:bg-red-900/50">
                {character.avatar ? (
                  <img
                    src={character.avatar}
                    alt={`${character.name} YouTube profile picture`}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                    onError={(event) => { event.currentTarget.style.display = 'none'; }}
                  />
                ) : (
                  <span>{character.name.slice(0, 1).toUpperCase()}</span>
                )}
              </div>
              <h3 className="break-words text-lg font-bold text-white">{character.name}</h3>
              <p className="mt-1 min-h-10 text-xs leading-relaxed text-zinc-500">Main character · VengeanceSMP</p>
              <a href={character.channel} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex max-w-full items-center gap-2 rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs font-semibold text-zinc-200 transition-colors hover:border-red-500/60 hover:text-white">
                <ExternalLink className="h-3.5 w-3.5 shrink-0 text-red-400" />
                <span className="break-all">{character.channelLabel}</span>
              </a>
            </article>
          ))}
        </div>
        <p className="mt-4 text-xs text-zinc-500">Profile pictures load from the linked YouTube channels where available. Kingcoolcat's channel is banned/unavailable, so a letter placeholder is shown until a profile image is provided.</p>
      </section>

      {/* LATEST UPLOADS: intentionally marked until exact channel URLs/feed IDs are configured. */}
      <section id="latest-uploads" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/70 p-6 sm:p-8">
          <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-red-950/30 blur-3xl" />
          <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-red-400">From the creators</span>
              <h2 className="mt-1 font-cinzel text-3xl font-bold text-white">Latest Uploads</h2>
              <p className="mt-2 max-w-2xl text-sm text-zinc-400">Latest uploads are planned for this section. The creator links are connected, but automatic recent-video fetching still needs a reliable YouTube feed/API integration.</p>
            </div>
            <div className="shrink-0 rounded-xl border border-amber-500/30 bg-amber-950/30 px-4 py-3 text-center">
              <span className="block text-[10px] font-bold uppercase tracking-[0.2em] text-amber-400">Under Development</span>
              <span className="mt-1 block text-xs text-zinc-300">Auto-fetch not connected yet</span>
            </div>
          </div>
          <div className="relative mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {[
              { name: 'JstWrxth', channel: 'https://youtube.com/@ignjstwrxth' },
              { name: 'ItzSwiftonic', channel: 'https://youtube.com/@ignitzswiftonic' },
              { name: 'Kyron', channel: 'https://youtube.com/@kryon-c5m' },
              { name: 'Kingcoolcat', channel: 'https://www.youtube.com/results?search_query=Kingcoolcat' },
              { name: 'EvolutionBattle', channel: 'https://youtube.com/@evolutionbattleyt' },
            ].map((creator) => (
              <a key={creator.name} href={creator.channel} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-950/60 px-4 py-3 text-sm text-zinc-300 transition-colors hover:border-red-500/40 hover:text-white">
                <span>{creator.name}</span><ExternalLink className="h-3.5 w-3.5 text-zinc-500" />
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* QUICK JUMP COMMUNITY TILES                                                */}
      {/* ========================================================================= */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <button
            onClick={() => onNavigate('rules')}
            className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 text-left hover:border-red-500/60 hover:bg-zinc-900/90 transition-all group"
          >
            <Shield className="h-6 w-6 text-red-400 mb-2 group-hover:scale-110 transition-transform" />
            <h4 className="font-bold text-white text-base">Server Rules</h4>
            <p className="text-xs text-zinc-400 mt-1">
              Zero-tolerance hacks, combat tagging protocols, and griefing bounds.
            </p>
          </button>

          <button
            onClick={() => onNavigate('promotion')}
            className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 text-left hover:border-amber-500/60 hover:bg-zinc-900/90 transition-all group"
          >
            <Sparkles className="h-6 w-6 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
            <h4 className="font-bold text-white text-base">Promote Vengeance</h4>
            <p className="text-xs text-zinc-400 mt-1">
              Invite friends, record TikToks, and earn creator rewards.
            </p>
          </button>

          <button
            onClick={() => {
              onNavigate('tier-list');
              onTriggerUnderDevelopment('Tier List ranking engine is currently in active calibration.');
            }}
            className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 text-left hover:border-purple-500/60 hover:bg-zinc-900/90 transition-all group"
          >
            <Trophy className="h-6 w-6 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
            <h4 className="font-bold text-white text-base flex items-center justify-between">
              <span>Tier List</span>
              <span className="text-[10px] text-amber-400 font-code font-bold uppercase">Dev</span>
            </h4>
            <p className="text-xs text-zinc-400 mt-1">
              PvP, building, strategy, and creator rankings.
            </p>
          </button>

          <button
            onClick={() => onNavigate('faq')}
            className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 text-left hover:border-blue-500/60 hover:bg-zinc-900/90 transition-all group"
          >
            <Users className="h-6 w-6 text-blue-400 mb-2 group-hover:scale-110 transition-transform" />
            <h4 className="font-bold text-white text-base">FAQ & Guides</h4>
            <p className="text-xs text-zinc-400 mt-1">
              Connection guides, 1.21.11 crossplay setup, and role auditions.
            </p>
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* FINAL LARGE DISCORD BANNER                                                */}
      {/* ========================================================================= */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl border-2 border-indigo-600/60 bg-gradient-to-r from-indigo-950/70 via-zinc-950 to-purple-950/70 p-8 sm:p-12 text-center shadow-2xl">
          <div className="max-w-2xl mx-auto space-y-4">
            <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-white">
              Join Vengeance<span className="text-indigo-400">.</span>
            </h2>
            <p className="font-cinzel text-base sm:text-xl font-bold tracking-wide text-zinc-300">
              Your story. Your choices. Your legacy.
            </p>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
              Meet the community, participate in creator events, share videos, and help shape the next Vengeance story.
            </p>

            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href={SERVER_CONFIG.discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => sound.playLevelUp()}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-8 py-4 text-base font-extrabold text-white shadow-xl shadow-indigo-950 hover:bg-indigo-500 active:scale-[0.98] transition-all"
              >
                <span>JOIN DISCORD</span>
                <ExternalLink className="h-4 w-4" />
              </a>

              <button
                onClick={() => {
                  sound.playLevelUp();
                  navigator.clipboard.writeText(SERVER_CONFIG.ip);
                }}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl border border-zinc-700 bg-zinc-900/90 px-6 py-4 text-sm font-bold text-zinc-200 hover:border-zinc-500 hover:text-white"
              >
                <span>Copy IP: {SERVER_CONFIG.ip}</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
