import React from 'react';
import { X, Shield, Swords, Skull, Flame, Award, Clock, Crosshair, ChevronRight } from 'lucide-react';
import { MemberProfile } from '../types';
import { sound } from '../utils/audio';

interface MemberModalProps {
  member: MemberProfile | null;
  onClose: () => void;
}

export const MemberModal: React.FC<MemberModalProps> = ({ member, onClose }) => {
  if (!member) return null;


  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={() => {
        sound.playClick();
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-2xl overflow-hidden rounded-xl border border-zinc-700 bg-zinc-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner */}
        <div className="relative h-28 w-full bg-gradient-to-r from-red-950 via-zinc-900 to-purple-950 px-6 py-4">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-red-400">
                Official SMP Player Dossier
              </span>
              <h2 className="font-cinzel text-2xl font-bold text-white flex items-center gap-2">
                {member.username}
                <span className={`inline-block h-2 w-2 rounded-full ${member.status === 'Online' ? 'bg-emerald-400' : member.status === 'AFK' ? 'bg-amber-400' : 'bg-zinc-600'}`} />
              </h2>
              <div className="flex items-center gap-2 text-xs text-zinc-300">
                <span>{member.role}</span>
                <span>·</span>
                <span>Vengeance SMP</span>
                <span>·</span>
                <span>Member since {member.joinDate}</span>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="max-h-[75vh] overflow-y-auto p-6 space-y-6">
          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3">
              <span className="text-xs text-zinc-500">Player Kills</span>
              <p className="font-code text-xl font-bold text-red-400">{member.kills}</p>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3">
              <span className="text-xs text-zinc-500">Deaths / K/D</span>
              <p className="font-code text-xl font-bold text-zinc-200">
                {member.deaths} <span className="text-xs font-normal text-emerald-400">({member.kdRatio})</span>
              </p>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3">
              <span className="text-xs text-zinc-500">Active Bounty</span>
              <p className="font-code text-xl font-bold text-amber-400">${member.bounty.toLocaleString()}</p>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3">
              <span className="text-xs text-zinc-500">Playtime</span>
              <p className="font-code text-xl font-bold text-purple-400">{member.playtimeHours} hrs</p>
            </div>
          </div>

          {/* Quote & Bio */}
          <div className="rounded-lg border-l-4 border-red-500 bg-zinc-950/80 p-4">
            <p className="italic text-zinc-200">"{member.quote}"</p>
            <p className="mt-2 text-xs text-zinc-400">{member.bio}</p>
          </div>

          {/* Signature Weapon Showcase */}
          <div className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Swords className="h-3.5 w-3.5" /> Signature Weapon
              </span>
              <span className="text-xs font-code text-zinc-400">Combat Style: {member.combatStyle}</span>
            </div>
            <p className="text-base font-bold text-zinc-100">{member.favoriteWeapon}</p>
            <p className="text-xs text-zinc-400 font-code">{member.weaponLore}</p>
          </div>

          {/* Loadout Inspection */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5 text-zinc-300" /> Active Battle Loadout ({member.gearTier})
            </h3>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 text-xs">
              <div className="rounded border border-zinc-800/80 bg-zinc-950/40 p-2.5">
                <span className="text-zinc-500 block">Armor Set:</span>
                <span className="text-zinc-300 block font-mono text-[11px] mt-0.5">{member.loadout.helmet}</span>
                <span className="text-zinc-300 block font-mono text-[11px]">{member.loadout.chestplate}</span>
                <span className="text-zinc-300 block font-mono text-[11px]">{member.loadout.leggings}</span>
                <span className="text-zinc-300 block font-mono text-[11px]">{member.loadout.boots}</span>
              </div>
              <div className="rounded border border-zinc-800/80 bg-zinc-950/40 p-2.5 flex flex-col justify-between">
                <div>
                  <span className="text-zinc-500 block">Hands & Offhand:</span>
                  <span className="text-red-300 font-mono text-[11px] block mt-0.5">Main: {member.loadout.mainHand}</span>
                  <span className="text-amber-300 font-mono text-[11px] block">Off: {member.loadout.offHand}</span>
                </div>
                <div className="mt-2 pt-2 border-t border-zinc-800">
                  <span className="text-zinc-500 block">Inventory Stock:</span>
                  <span className="text-zinc-400 font-mono text-[10px] block">
                    {member.loadout.specialItems.join(' · ')}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-zinc-800 bg-zinc-950 px-6 py-3 text-xs text-zinc-400">
          <span>Server IP: <span className="font-code text-red-400">vengeancesmp.playwithbao.com</span></span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="rounded bg-zinc-800 px-3 py-1 font-medium text-zinc-200 hover:bg-zinc-700"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
