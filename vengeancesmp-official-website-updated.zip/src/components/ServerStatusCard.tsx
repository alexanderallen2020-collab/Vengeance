import React, { useCallback, useEffect, useState } from 'react';
import { Copy, Check, Radio, Signal, Users, Layers, ShieldCheck, Sparkles } from 'lucide-react';
import { SERVER_CONFIG } from '../data/serverData';
import { sound } from '../utils/audio';

type ServerStatus = { online: boolean; players?: { online: number; max: number }; version?: string; hostname?: string };

export const ServerStatusCard: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState<ServerStatus | null>(null);
  const [checking, setChecking] = useState(true);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const checkStatus = useCallback(async () => {
    try {
      setChecking(true);
      const response = await fetch(`https://api.mcsrvstat.us/3/${encodeURIComponent(SERVER_CONFIG.ip)}`, { cache: 'no-store' });
      if (!response.ok) throw new Error('Status lookup failed');
      const data = await response.json();
      setStatus({ online: Boolean(data.online), players: data.players, version: data.version, hostname: data.hostname });
      setLastChecked(new Date());
    } catch {
      setStatus(null);
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    void checkStatus();
    const interval = window.setInterval(() => void checkStatus(), 60000);
    return () => window.clearInterval(interval);
  }, [checkStatus]);

  const handleCopyIp = async () => {
    sound.playLevelUp();
    try {
      await navigator.clipboard.writeText(SERVER_CONFIG.ip);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch { setCopied(false); }
  };

  const statusLabel = checking && !status ? 'Checking server…' : status === null ? 'Status unavailable' : status.online ? 'Server online' : 'Server offline';
  const dotClass = status?.online ? 'bg-emerald-400' : status === null ? 'bg-amber-400' : 'bg-red-400';

  if (compact) {
    return <div className="flex flex-wrap items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-900/90 px-3 py-1.5 text-xs backdrop-blur-md">
      <span className={`h-2 w-2 rounded-full ${dotClass} ${status?.online ? 'animate-pulse' : ''}`} />
      <span className="font-code text-zinc-200 font-bold">{SERVER_CONFIG.ip}</span><span className="text-zinc-500">·</span>
      <span className="font-code text-zinc-400">{status?.online && status.players ? `${status.players.online}/${status.players.max}` : statusLabel}</span>
      <button onClick={handleCopyIp} className="ml-1 text-red-400 hover:text-white" title="Copy IP">{copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}</button>
    </div>;
  }

  return <div className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/90 p-5 shadow-2xl backdrop-blur-md">
    <div className="pointer-events-none absolute right-0 top-0 h-32 w-32 bg-red-950/20 blur-3xl" />
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-center">
      <div className="space-y-1.5 lg:col-span-5">
        <div className="flex flex-wrap items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${dotClass} ${status?.online ? 'animate-pulse' : ''}`} /><span className={`text-xs font-semibold uppercase tracking-wider ${status?.online ? 'text-emerald-400' : status === null ? 'text-amber-400' : 'text-red-400'}`}>{statusLabel}</span><span className="text-zinc-600">·</span><span className="text-[11px] text-zinc-500">Auto-refreshes every 60 seconds</span></div>
        <div className="flex items-center gap-2"><span className="select-all break-all font-code text-lg font-bold tracking-tight text-white sm:text-2xl">{SERVER_CONFIG.ip}</span><button onClick={handleCopyIp} title="Copy Server IP" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-red-500/40 bg-red-950/60 text-red-300 transition-colors hover:bg-red-900 hover:text-white">{copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}</button></div>
        <p className="text-xs text-zinc-400">Minecraft Java · Port <span className="font-code text-zinc-200">{SERVER_CONFIG.port}</span></p>
      </div>
      <div className="grid grid-cols-3 gap-3 border-y border-zinc-800/80 py-3 lg:col-span-4 lg:border-y-0 lg:border-x lg:px-6">
        <div><span className="block text-xs text-zinc-500">Players Online</span><div className="mt-1 flex items-center gap-1.5"><Users className="h-3.5 w-3.5 text-red-400" /><span className="font-code text-base font-bold text-zinc-100 sm:text-lg">{status?.online && status.players ? status.players.online : '—'}<span className="text-xs font-normal text-zinc-500">{status?.online && status.players ? ` / ${status.players.max}` : ''}</span></span></div></div>
        <div><span className="block text-xs text-zinc-500">Version</span><div className="mt-1 flex items-center gap-1.5"><Layers className="h-3.5 w-3.5 text-purple-400" /><span className="font-code text-sm font-bold text-zinc-100">{status?.version || '—'}</span></div></div>
        <div><span className="block text-xs text-zinc-500">Data</span><div className="mt-1 flex items-center gap-1.5"><Signal className="h-3.5 w-3.5 text-zinc-400" /><span className="text-xs text-zinc-300">{status ? 'Live lookup' : 'Unavailable'}</span></div></div>
      </div>
      <div className="flex flex-col gap-2 lg:col-span-3"><div className="flex items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-950/60 p-3"><ShieldCheck className="h-4 w-4 shrink-0 text-emerald-400" /><div><p className="text-xs font-semibold text-zinc-200">Real server data</p><p className="mt-0.5 text-[11px] text-zinc-500">No simulated player counts</p></div></div><button onClick={() => void checkStatus()} className="inline-flex items-center justify-center gap-2 rounded-lg border border-zinc-700 bg-zinc-800/80 px-3 py-2 text-xs font-semibold text-zinc-200 transition-colors hover:border-red-500/50 hover:text-white"><Radio className="h-3.5 w-3.5" /> Check now</button></div>
    </div>
    <div className="mt-4 flex items-center justify-between border-t border-zinc-800/80 pt-3 text-[10px] text-zinc-600"><span><Sparkles className="mr-1 inline h-3 w-3" />Public status lookup</span><span>{lastChecked ? `Last checked ${lastChecked.toLocaleTimeString()}` : 'Waiting for first check'}</span></div>
  </div>;
};
