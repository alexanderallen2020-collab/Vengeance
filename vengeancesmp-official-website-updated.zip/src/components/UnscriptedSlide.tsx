import React, { useState, useMemo } from 'react';
import { 
  Swords, Shield, Search, Copy, Check, Users, Trophy, AlertTriangle, 
  ExternalLink, ChevronDown, ChevronUp, Sparkles, Flame, Clock, 
  ArrowUpDown, Skull, Target, Crosshair, Award, Radio, Video
} from 'lucide-react';
import { 
  SERVER_RULES, MEMBER_PROFILES, LEADERBOARD_DATA, 
  LIVE_KILL_FEED_ITEMS, SERVER_CONFIG 
} from '../data/serverData';
import { MemberProfile, LeaderboardEntry, ServerRule } from '../types';
import { ServerStatusCard } from './ServerStatusCard';
import { sound } from '../utils/audio';

interface UnscriptedSlideProps {
  onSelectMember: (member: MemberProfile) => void;
}

export const UnscriptedSlide: React.FC<UnscriptedSlideProps> = ({ onSelectMember }) => {
  // State for Server Connection
  const [copiedIp, setCopiedIp] = useState(false);
  const [copiedPort, setCopiedPort] = useState(false);

  // State for Rules
  const [ruleSearch, setRuleSearch] = useState('');
  const [selectedRuleCategory, setSelectedRuleCategory] = useState<string>('All');
  const [expandedRuleId, setExpandedRuleId] = useState<string | null>('rule-1');

  // State for Members
  const [memberSearch, setMemberSearch] = useState('');

  // State for Leaderboard
  const [leaderboardMetric, setLeaderboardMetric] = useState<'kills' | 'kd' | 'bounty' | 'playtime' | 'streak'>('kills');
  const [leaderboardSearch, setLeaderboardSearch] = useState('');

  // Handle Copy IP
  const handleCopyIp = () => {
    sound.playLevelUp();
    navigator.clipboard.writeText('play.vengeancesmp.net');
    setCopiedIp(true);
    setTimeout(() => setCopiedIp(false), 2200);
  };

  const handleCopyPort = () => {
    sound.playClick();
    navigator.clipboard.writeText('25565');
    setCopiedPort(true);
    setTimeout(() => setCopiedPort(false), 2200);
  };

  // Filter Rules
  const filteredRules = useMemo(() => {
    return SERVER_RULES.filter((rule) => {
      const matchesCategory = selectedRuleCategory === 'All' || rule.category === selectedRuleCategory;
      const q = ruleSearch.toLowerCase();
      const matchesSearch = 
        rule.title.toLowerCase().includes(q) ||
        rule.shortDescription.toLowerCase().includes(q) ||
        rule.fullRule.toLowerCase().includes(q);
      return matchesCategory && matchesSearch;
    });
  }, [ruleSearch, selectedRuleCategory]);

  // Filter Members
  const filteredMembers = useMemo(() => {
    return MEMBER_PROFILES.filter((member) => {
      const q = memberSearch.toLowerCase();
      const matchesSearch = 
        member.username.toLowerCase().includes(q) ||
        member.role.toLowerCase().includes(q) ||
        member.combatStyle.toLowerCase().includes(q) ||
        member.favoriteWeapon.toLowerCase().includes(q);
      return matchesSearch;
    });
  }, [memberSearch]);

  // Sorted and Filtered Leaderboard
  const sortedLeaderboard = useMemo(() => {
    const list = [...LEADERBOARD_DATA];
    if (leaderboardMetric === 'kills') {
      list.sort((a, b) => b.kills - a.kills);
    } else if (leaderboardMetric === 'kd') {
      list.sort((a, b) => b.kdRatio - a.kdRatio);
    } else if (leaderboardMetric === 'bounty') {
      list.sort((a, b) => b.bounty - a.bounty);
    } else if (leaderboardMetric === 'playtime') {
      list.sort((a, b) => b.playtimeHours - a.playtimeHours);
    } else if (leaderboardMetric === 'streak') {
      list.sort((a, b) => b.streak - a.streak);
    }

    if (!leaderboardSearch) return list;
    return list.filter((item) => item.username.toLowerCase().includes(leaderboardSearch.toLowerCase()));
  }, [leaderboardMetric, leaderboardSearch]);

  const topThree = useMemo(() => sortedLeaderboard.slice(0, 3), [sortedLeaderboard]);

  return (
    <div className="w-full space-y-20 pb-24">
      {/* ========================================================================= */}
      {/* HERO SECTION                                                             */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden border-b border-zinc-800 bg-zinc-950 pt-8 pb-16">
        {/* Cinematic Backdrop Image with Dark Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/hero_unscripted_smp_1790685293657.jpg"
            alt="VengeanceSMP Obsidian Fortress"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-35 filter brightness-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-zinc-950/40" />
          <div className="absolute inset-0 bg-radial from-red-950/20 via-transparent to-transparent" />
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            {/* Prompt Required Copy for Unscripted SMP */}
            <div className="inline-flex items-center gap-2 rounded-full border border-red-500/30 bg-red-950/40 px-3 py-1 text-xs font-semibold text-red-400">
              <span className="flex h-2 w-2 rounded-full bg-red-500 animate-ping" />
              <span>UNSCRIPTED SMP · SEPARATE TEMPORARY REALM</span>
            </div>

            <h1 className="font-cinzel text-4xl font-extrabold tracking-tight text-white sm:text-6xl text-balance">
              The Unscripted SMP
            </h1>

            <p className="text-base sm:text-lg text-zinc-200 leading-relaxed max-w-2xl font-medium">
              The Unscripted SMP is a separate temporary server hosted every few weeks.
            </p>

            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed max-w-2xl">
              There is no planned storyline. Players create their own stories through building, PvP, rivalries, exploration, and survival. Everyone is allowed to record their own POV.
            </p>

            {/* Quick Action Button: Learn About Unscripted SMP */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href="#unscripted-details"
                onClick={() => sound.playClick()}
                className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-5 py-3 text-xs font-bold text-white shadow-lg shadow-red-950 hover:bg-red-500 transition-colors"
              >
                <span>Learn About Unscripted SMP</span>
                <ChevronDown className="h-4 w-4" />
              </a>

              <a
                href={SERVER_CONFIG.discordUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => sound.playLevelUp()}
                className="inline-flex items-center gap-2 rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-3 text-xs font-semibold text-zinc-200 hover:text-white"
              >
                <span>Join Discord Announcement Channel</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>

          {/* Real-time Server Connection Dashboard Bar */}
          <div id="connect-section" className="mt-10">
            <ServerStatusCard />
          </div>
        </div>
      </section>

      {/* Unscripted Overview Details Anchor */}
      <div id="unscripted-details" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 sm:p-8 space-y-4">
          <span className="text-xs font-semibold uppercase tracking-wider text-red-400">
            Format & Schedule
          </span>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-white">
            How the Unscripted SMP Operates
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2 text-xs sm:text-sm text-zinc-300 leading-relaxed">
            <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 space-y-2">
              <h4 className="font-bold text-white text-base flex items-center gap-1.5">
                <Clock className="h-4 w-4 text-red-400" /> Temporary Every Few Weeks
              </h4>
              <p>
                Each Unscripted cycle runs for a limited competitive sprint on a fresh seed with tight borders. Win conditions and bounty pots reset each sprint.
              </p>
            </div>
            <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 space-y-2">
              <h4 className="font-bold text-white text-base flex items-center gap-1.5">
                <Swords className="h-4 w-4 text-amber-400" /> Zero Planned Scripts
              </h4>
              <p>
                Alliances form organically and break ruthlessly. No admins dictate who lives or dies—your survival depends 100% on your game sense and combat skill.
              </p>
            </div>
            <div className="rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 space-y-2">
              <h4 className="font-bold text-white text-base flex items-center gap-1.5">
                <Video className="h-4 w-4 text-purple-400" /> POV Creators Welcome
              </h4>
              <p>
                Everyone is encouraged to record, stream, and publish their unedited perspective. Creator ranks and community highlight reels are provided.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: SERVER RULES CODEX                                            */}
      {/* ========================================================================= */}
      <section id="rules-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-zinc-800 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-red-400">
              <Shield className="h-4 w-4" />
              <span>Mandatory Server Guidelines</span>
            </div>
            <h2 className="font-cinzel text-3xl font-bold text-white mt-1">
              Official Server Rules Codex
            </h2>
            <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
              VengeanceSMP operates on a vanilla+ hardcore ethos. Review the code of conduct before setting foot outside spawn.
            </p>
          </div>

          {/* Rules Category Filter */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-lg">
            {['All', 'Combat & PvP', 'Exploits & Fair Play', 'Raiding & Griefing', 'Economy & Trading', 'Community Conduct'].map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  sound.playClick();
                  setSelectedRuleCategory(cat);
                }}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  selectedRuleCategory === cat
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Search Rules Bar */}
        <div className="mt-6 flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input
              type="text"
              value={ruleSearch}
              onChange={(e) => setRuleSearch(e.target.value)}
              placeholder="Search rules by keyword (e.g. 'combat log', 'xray', 'tnt cannon', 'bounty', 'doxxing')..."
              className="w-full rounded-xl border border-zinc-800 bg-zinc-900/80 pl-10 pr-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:border-red-500 focus:outline-none focus:ring-1 focus:ring-red-500"
            />
          </div>
          {ruleSearch && (
            <button
              onClick={() => setRuleSearch('')}
              className="rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-xs text-zinc-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Rules Accordion List */}
        <div className="mt-6 space-y-3">
          {filteredRules.length === 0 ? (
            <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-8 text-center text-sm text-zinc-400">
              No server rules matched your search query "{ruleSearch}".
            </div>
          ) : (
            filteredRules.map((rule) => {
              const isExpanded = expandedRuleId === rule.id;
              return (
                <div
                  key={rule.id}
                  className="rounded-xl border border-zinc-800/80 bg-zinc-900/60 transition-all overflow-hidden"
                >
                  {/* Rule Header Bar */}
                  <button
                    onClick={() => {
                      sound.playClick();
                      setExpandedRuleId(isExpanded ? null : rule.id);
                    }}
                    className="w-full flex items-center justify-between p-4 sm:p-5 text-left transition-colors hover:bg-zinc-800/40"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 font-code text-xs font-bold text-red-400">
                        #{rule.number}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-zinc-400 font-semibold">{rule.category}</span>
                          <span className="text-zinc-600">·</span>
                          <span className={`text-[11px] font-semibold ${
                            rule.severity === 'critical' ? 'text-red-400' : rule.severity === 'high' ? 'text-amber-400' : 'text-zinc-400'
                          }`}>
                            Penalty: {rule.penalty}
                          </span>
                        </div>
                        <h3 className="font-semibold text-zinc-100 text-sm sm:text-base mt-0.5">
                          {rule.title}
                        </h3>
                        <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">
                          {rule.shortDescription}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-zinc-400">
                      {isExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </div>
                  </button>

                  {/* Expanded Rule Details */}
                  {isExpanded && (
                    <div className="border-t border-zinc-800/80 bg-zinc-950/60 p-5 space-y-4 text-xs">
                      <div>
                        <span className="font-semibold uppercase tracking-wider text-zinc-400 block mb-1">
                          Full Rule Specification:
                        </span>
                        <p className="text-zinc-300 leading-relaxed text-sm">
                          {rule.fullRule}
                        </p>
                      </div>

                      {/* Examples Comparison Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        <div className="rounded-lg border border-emerald-950/60 bg-emerald-950/20 p-3">
                          <span className="font-semibold text-emerald-400 flex items-center gap-1.5 mb-2">
                            <Check className="h-4 w-4" /> Permitted Gameplay Actions
                          </span>
                          <ul className="space-y-1.5 text-zinc-300">
                            {rule.examplesAllowed.map((ex, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <span className="text-emerald-500 font-bold">•</span>
                                <span>{ex}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="rounded-lg border border-red-950/60 bg-red-950/20 p-3">
                          <span className="font-semibold text-red-400 flex items-center gap-1.5 mb-2">
                            <AlertTriangle className="h-4 w-4" /> Prohibited Violations & Exploits
                          </span>
                          <ul className="space-y-1.5 text-zinc-300">
                            {rule.examplesProhibited.map((ex, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <span className="text-red-500 font-bold">•</span>
                                <span>{ex}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60 text-zinc-400">
                        <span>Staff Enforcement: Automated Anticheat + 24/7 Moderator Logs</span>
                        <span className="font-code text-red-400">Rule ID: {rule.id}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 2: MEMBER PROFILES SYSTEM                                        */}
      {/* ========================================================================= */}
      <section id="members-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-zinc-800 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-red-400">
              <Users className="h-4 w-4" />
              <span>Server Player Registry</span>
            </div>
            <h2 className="font-cinzel text-3xl font-bold text-white mt-1">
              Player Profiles
            </h2>
            <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
              Inspect the battle records, signature loadouts, and tactical specializations of the server's most notorious players.
            </p>
          </div>
        </div>

        {/* Member Search */}
        <div className="mt-6">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input
              type="text"
              value={memberSearch}
              onChange={(e) => setMemberSearch(e.target.value)}
              placeholder="Search member by username, weapon, or combat style..."
              className="w-full rounded-xl border border-zinc-800 bg-zinc-900/80 pl-10 pr-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-500 focus:border-red-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Members Cards Grid */}
        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredMembers.map((member) => {
            return (
              <div
                key={member.id}
                className="group relative flex flex-col justify-between rounded-xl border border-zinc-800/80 bg-zinc-900/60 p-5 transition-all hover:border-zinc-700 hover:bg-zinc-900/90 hover:shadow-xl"
              >
                <div>
                  {/* Top card bar */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      {/* Avatar Head Icon with Minecraft style border */}
                      <div className="relative flex h-12 w-12 items-center justify-center rounded-lg border-2 border-zinc-700 bg-zinc-800 overflow-hidden shadow-inner">
                        {/* Authentic pixel character avatar silhouette */}
                        <div className="flex flex-col items-center justify-center font-bold text-red-400">
                          <span className="font-cinzel text-lg">{member.username.charAt(0)}</span>
                        </div>
                        <span className={`absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full ring-2 ring-zinc-900 ${
                          member.status === 'Online' ? 'bg-emerald-400' : member.status === 'AFK' ? 'bg-amber-400' : 'bg-zinc-600'
                        }`} />
                      </div>

                      <div>
                        <h3 className="font-bold text-zinc-100 text-base group-hover:text-red-400 transition-colors">
                          {member.username}
                        </h3>
                        <p className="text-xs text-zinc-400">{member.role}</p>
                      </div>
                    </div>


                  </div>

                  {/* Quote */}
                  <div className="mt-4 rounded border-l-2 border-red-500/80 bg-zinc-950/60 px-3 py-2 text-xs italic text-zinc-300">
                    "{member.quote}"
                  </div>

                  {/* Core Metrics */}
                  <div className="mt-4 grid grid-cols-3 gap-2 border-y border-zinc-800/80 py-3 text-center">
                    <div>
                      <span className="text-[11px] text-zinc-500 block">Kills</span>
                      <span className="font-code font-bold text-sm text-red-400">{member.kills}</span>
                    </div>
                    <div>
                      <span className="text-[11px] text-zinc-500 block">K/D Ratio</span>
                      <span className="font-code font-bold text-sm text-zinc-200">{member.kdRatio}</span>
                    </div>
                    <div>
                      <span className="text-[11px] text-zinc-500 block">Bounty</span>
                      <span className="font-code font-bold text-sm text-amber-400">${member.bounty.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Weapon of Choice */}
                  <div className="mt-3 text-xs space-y-1">
                    <span className="text-zinc-500 block">Signature Weapon:</span>
                    <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                      <Swords className="h-3.5 w-3.5 text-red-400" /> {member.favoriteWeapon}
                    </span>
                  </div>
                </div>

                {/* Inspect Button Action */}
                <div className="mt-5 pt-3 border-t border-zinc-800/80">
                  <button
                    onClick={() => {
                      sound.playClick();
                      onSelectMember(member);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-800/80 py-2 text-xs font-semibold text-zinc-200 transition-colors hover:border-red-500 hover:bg-red-950/50 hover:text-white"
                  >
                    <span>Inspect Full Loadout</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SECTION 3: INTEGRATED LEADERBOARD SYSTEM                                  */}
      {/* ========================================================================= */}
      <section id="leaderboard-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-zinc-800 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-red-400">
              <Trophy className="h-4 w-4" />
              <span>Competitive Rankings</span>
            </div>
            <h2 className="font-cinzel text-3xl font-bold text-white mt-1">
              Integrated Leaderboard System
            </h2>
            <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
              Real-time competitive standings automatically synced with the server core engine.
            </p>
          </div>

          {/* Metric Selector Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-lg">
            <button
              onClick={() => {
                sound.playClick();
                setLeaderboardMetric('kills');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                leaderboardMetric === 'kills' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Total Kills
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLeaderboardMetric('kd');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                leaderboardMetric === 'kd' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              K/D Ratio
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLeaderboardMetric('bounty');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                leaderboardMetric === 'bounty' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Active Bounty
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLeaderboardMetric('playtime');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                leaderboardMetric === 'playtime' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Playtime
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setLeaderboardMetric('streak');
              }}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                leaderboardMetric === 'streak' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Streak
            </button>
          </div>
        </div>

        {/* Podium Top 3 Display */}
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3 items-end">
          {/* 2nd Place */}
          {topThree[1] && (
            <div className="order-2 sm:order-1 rounded-xl border border-zinc-700 bg-zinc-900/60 p-5 text-center flex flex-col items-center">
              <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Rank #2</span>
              <div className="mt-2 flex h-14 w-14 items-center justify-center rounded-full border-2 border-zinc-400 bg-zinc-800 text-xl font-bold font-cinzel text-zinc-200">
                {topThree[1].username.charAt(0)}
              </div>
              <h4 className="mt-2 font-bold text-zinc-100">{topThree[1].username}</h4>
              <span className="text-xs text-zinc-400 uppercase">{topThree[1].tier}</span>
              <div className="mt-3 w-full border-t border-zinc-800 pt-2 text-xs">
                <span className="text-zinc-500">Metric Value: </span>
                <span className="font-code font-bold text-zinc-200">
                  {leaderboardMetric === 'kills' && `${topThree[1].kills} Kills`}
                  {leaderboardMetric === 'kd' && `${topThree[1].kdRatio} K/D`}
                  {leaderboardMetric === 'bounty' && `$${topThree[1].bounty.toLocaleString()}`}
                  {leaderboardMetric === 'playtime' && `${topThree[1].playtimeHours} Hours`}
                  {leaderboardMetric === 'streak' && `${topThree[1].streak} Killstreak`}
                </span>
              </div>
            </div>
          )}

          {/* 1st Place (Gold Centerpiece) */}
          {topThree[0] && (
            <div className="order-1 sm:order-2 rounded-xl border-2 border-amber-500/60 bg-gradient-to-b from-amber-950/30 to-zinc-900 p-6 text-center flex flex-col items-center shadow-xl shadow-amber-950/30">
              <div className="inline-flex items-center gap-1 text-xs font-extrabold text-amber-400 uppercase tracking-widest">
                <Trophy className="h-4 w-4" /> REIGNING CHAMPION #1
              </div>
              <div className="mt-2 flex h-16 w-16 items-center justify-center rounded-full border-2 border-amber-400 bg-amber-950/80 text-2xl font-bold font-cinzel text-amber-300 ring-4 ring-amber-500/20">
                {topThree[0].username.charAt(0)}
              </div>
              <h4 className="mt-2 font-bold text-white text-lg">{topThree[0].username}</h4>
              <span className="text-xs text-amber-300 uppercase font-semibold">{topThree[0].tier}</span>
              <div className="mt-3 w-full border-t border-amber-500/20 pt-2 text-xs">
                <span className="text-zinc-400">Record: </span>
                <span className="font-code font-bold text-amber-300 text-sm">
                  {leaderboardMetric === 'kills' && `${topThree[0].kills} Kills`}
                  {leaderboardMetric === 'kd' && `${topThree[0].kdRatio} K/D`}
                  {leaderboardMetric === 'bounty' && `$${topThree[0].bounty.toLocaleString()}`}
                  {leaderboardMetric === 'playtime' && `${topThree[0].playtimeHours} Hours`}
                  {leaderboardMetric === 'streak' && `${topThree[0].streak} Killstreak`}
                </span>
              </div>
            </div>
          )}

          {/* 3rd Place */}
          {topThree[2] && (
            <div className="order-3 rounded-xl border border-zinc-700 bg-zinc-900/60 p-5 text-center flex flex-col items-center">
              <span className="text-xs font-bold text-amber-700 uppercase tracking-widest">Rank #3</span>
              <div className="mt-2 flex h-14 w-14 items-center justify-center rounded-full border-2 border-amber-700 bg-zinc-800 text-xl font-bold font-cinzel text-amber-600">
                {topThree[2].username.charAt(0)}
              </div>
              <h4 className="mt-2 font-bold text-zinc-100">{topThree[2].username}</h4>
              <span className="text-xs text-zinc-400 uppercase">{topThree[2].tier}</span>
              <div className="mt-3 w-full border-t border-zinc-800 pt-2 text-xs">
                <span className="text-zinc-500">Metric Value: </span>
                <span className="font-code font-bold text-zinc-200">
                  {leaderboardMetric === 'kills' && `${topThree[2].kills} Kills`}
                  {leaderboardMetric === 'kd' && `${topThree[2].kdRatio} K/D`}
                  {leaderboardMetric === 'bounty' && `$${topThree[2].bounty.toLocaleString()}`}
                  {leaderboardMetric === 'playtime' && `${topThree[2].playtimeHours} Hours`}
                  {leaderboardMetric === 'streak' && `${topThree[2].streak} Killstreak`}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Search Player in Table */}
        <div className="mt-8 flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-zinc-500" />
            <input
              type="text"
              value={leaderboardSearch}
              onChange={(e) => setLeaderboardSearch(e.target.value)}
              placeholder="Search ranked player..."
              className="w-full rounded-lg border border-zinc-800 bg-zinc-900/80 pl-9 pr-3 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:border-red-500 focus:outline-none"
            />
          </div>
          <span className="text-xs text-zinc-500">Showing top {sortedLeaderboard.length} contenders</span>
        </div>

        {/* Detailed Leaderboard Table */}
        <div className="mt-4 overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-900/60">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-zinc-800 bg-zinc-950/80 text-zinc-400">
              <tr>
                <th className="px-4 py-3 font-semibold">Rank</th>
                <th className="px-4 py-3 font-semibold">Player</th>
                                <th className="px-4 py-3 font-semibold text-right">Kills</th>
                <th className="px-4 py-3 font-semibold text-right">Deaths</th>
                <th className="px-4 py-3 font-semibold text-right">K/D</th>
                <th className="px-4 py-3 font-semibold text-right">Active Bounty</th>
                <th className="px-4 py-3 font-semibold text-right">Playtime</th>
                <th className="px-4 py-3 font-semibold text-right">Streak</th>
                <th className="px-4 py-3 font-semibold text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 font-code text-zinc-200">
              {sortedLeaderboard.map((row, idx) => {
                const matchedMember = MEMBER_PROFILES.find((m) => m.username === row.username);
                return (
                  <tr
                    key={row.username}
                    className="hover:bg-zinc-800/40 transition-colors"
                  >
                    <td className="px-4 py-3 font-bold">
                      <span className={`inline-flex h-6 w-6 items-center justify-center rounded ${
                        idx === 0 ? 'bg-amber-500/20 text-amber-400 font-extrabold' :
                        idx === 1 ? 'bg-zinc-300/20 text-zinc-300 font-bold' :
                        idx === 2 ? 'bg-amber-700/20 text-amber-500 font-bold' : 'text-zinc-500'
                      }`}>
                        #{idx + 1}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-sans font-bold text-white flex items-center gap-2">
                      <span>{row.username}</span>
                      <span className="text-[10px] text-zinc-500 font-normal">({row.tier})</span>
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-red-400">{row.kills}</td>
                    <td className="px-4 py-3 text-right text-zinc-400">{row.deaths}</td>
                    <td className="px-4 py-3 text-right font-bold text-emerald-400">{row.kdRatio}</td>
                    <td className="px-4 py-3 text-right text-amber-400">${row.bounty.toLocaleString()}</td>
                    <td className="px-4 py-3 text-right text-zinc-300">{row.playtimeHours}h</td>
                    <td className="px-4 py-3 text-right font-bold text-purple-400">{row.streak}</td>
                    <td className="px-4 py-3 text-center">
                      {matchedMember ? (
                        <button
                          onClick={() => {
                            sound.playClick();
                            onSelectMember(matchedMember);
                          }}
                          className="rounded border border-zinc-700 bg-zinc-800 px-2 py-1 text-[11px] font-sans text-zinc-300 hover:border-red-500 hover:text-white"
                        >
                          Inspect
                        </button>
                      ) : (
                        <span className="text-zinc-600 text-[11px] font-sans">Private</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
