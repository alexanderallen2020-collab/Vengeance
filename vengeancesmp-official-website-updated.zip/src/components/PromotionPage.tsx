import React, { useState } from 'react';
import { 
  Megaphone, Users, Video, Smartphone, Sparkles, 
  Handshake, Copy, Check, Mail, ExternalLink, ArrowRight, Award 
} from 'lucide-react';
import { PROMOTION_CARDS, SERVER_CONFIG } from '../data/serverData';
import { sound } from '../utils/audio';

interface PromotionPageProps {
  onOpenContact: () => void;
  onTriggerUnderDevelopment: (feature: string) => void;
}

export const PromotionPage: React.FC<PromotionPageProps> = ({
  onOpenContact,
  onTriggerUnderDevelopment
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [customUsername, setCustomUsername] = useState('');
  const [generatedInvite, setGeneratedInvite] = useState('');

  const handleGenerateInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customUsername.trim()) return;
    sound.playLevelUp();
    const link = `https://vengeancesmp.playwithbao.com/ref/${customUsername.trim().toLowerCase()}`;
    setGeneratedInvite(link);
  };

  const handleCopyInvite = () => {
    if (!generatedInvite) return;
    sound.playLevelUp();
    navigator.clipboard.writeText(generatedInvite);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCardAction = (cardId: string, actionText: string) => {
    sound.playClick();
    if (cardId === 'invite-friends') {
      const el = document.getElementById('invite-generator');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (cardId === 'partner-communities' || cardId === 'create-videos') {
      onOpenContact();
    } else {
      onTriggerUnderDevelopment(`${actionText} portal is currently being integrated with our Discord bot.`);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-zinc-800 bg-gradient-to-r from-zinc-950 via-zinc-900 to-red-950/40 p-8 sm:p-12 shadow-2xl">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-red-500/40 bg-red-950/60 px-3.5 py-1 text-xs font-semibold text-red-300">
            <Megaphone className="h-3.5 w-3.5 text-red-400" />
            <span>COMMUNITY EXPANSION INITIATIVE</span>
          </div>

          <h1 className="font-cinzel text-4xl sm:text-6xl font-extrabold text-white">
            Help Vengeance Grow
          </h1>

          <p className="text-sm sm:text-base text-zinc-300 leading-relaxed max-w-2xl">
            Vengeance thrives on player rivalries, epic builds, and dramatic storylines. As a player-driven server, every new player, video, clip, and partnership expands our universe. Discover the ways you can support our world and unlock exclusive creator perks.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                sound.playClick();
                onOpenContact();
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-5 py-3 text-xs font-bold text-white shadow-lg shadow-red-950 hover:bg-red-500 transition-colors"
            >
              <Mail className="h-4 w-4" />
              <span>Contact Us</span>
            </button>

            <a
              href={SERVER_CONFIG.discordUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => sound.playLevelUp()}
              className="inline-flex items-center gap-2 rounded-xl border border-zinc-700 bg-zinc-900 px-5 py-3 text-xs font-semibold text-zinc-200 hover:text-white transition-colors"
            >
              <span>Join Creator Discord</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Required Promotion Pillars Grid */}
      <div className="space-y-6">
        <div className="border-b border-zinc-800 pb-4">
          <span className="text-xs font-semibold uppercase tracking-wider text-red-400">
            Opportunities
          </span>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-white mt-0.5">
            How You Can Make an Impact
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PROMOTION_CARDS.map((card) => (
            <div
              key={card.id}
              className="group relative flex flex-col justify-between rounded-2xl border border-zinc-800 bg-zinc-900/60 p-6 transition-all hover:border-zinc-700 hover:bg-zinc-900/90 hover:shadow-xl"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                    {card.tag}
                  </span>
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-red-400 group-hover:scale-110 transition-transform">
                    {card.id === 'invite-friends' && <Users className="h-4 w-4" />}
                    {card.id === 'create-videos' && <Video className="h-4 w-4" />}
                    {card.id === 'make-tiktoks' && <Smartphone className="h-4 w-4" />}
                    {card.id === 'promote-server' && <Megaphone className="h-4 w-4" />}
                    {card.id === 'partner-communities' && <Handshake className="h-4 w-4" />}
                    {card.id === 'bring-new-players' && <Sparkles className="h-4 w-4" />}
                  </div>
                </div>

                <h3 className="font-cinzel text-xl font-bold text-white mt-3">
                  {card.title}
                </h3>

                <p className="text-xs text-zinc-300 leading-relaxed mt-2">
                  {card.description}
                </p>

                <div className="mt-4 rounded-lg border border-zinc-800/80 bg-zinc-950/60 p-2.5 text-xs text-zinc-400 flex items-start gap-2">
                  <Award className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
                  <span>
                    <strong className="text-zinc-200">Perk:</strong> {card.perk}
                  </span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-800">
                <button
                  onClick={() => handleCardAction(card.id, card.actionText)}
                  className="w-full flex items-center justify-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-800/80 py-2 text-xs font-semibold text-zinc-200 hover:border-red-500 hover:bg-red-950/50 hover:text-white transition-colors"
                >
                  <span>{card.actionText}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Referral Link Generator */}
      <div id="invite-generator" className="rounded-2xl border border-zinc-800 bg-zinc-900/80 p-6 sm:p-8">
        <div className="max-w-2xl space-y-4">
          <span className="text-xs font-semibold uppercase tracking-wider text-red-400 flex items-center gap-1.5">
            <Users className="h-4 w-4" /> Personal Referral Generator
          </span>
          <h3 className="font-cinzel text-2xl font-bold text-white">
            Create Your Custom Recruitment Link
          </h3>
          <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
            Enter your Minecraft username to generate a direct link. When newcomers join and list you as their recruiter, you both receive bonus starter resources and unique tags.
          </p>

          <form onSubmit={handleGenerateInvite} className="flex flex-col sm:flex-row gap-3 pt-2">
            <input
              type="text"
              value={customUsername}
              onChange={(e) => setCustomUsername(e.target.value)}
              placeholder="Your Minecraft In-Game Name..."
              className="flex-1 rounded-xl border border-zinc-800 bg-zinc-950 px-4 py-3 text-xs text-zinc-200 placeholder-zinc-500 focus:border-red-500 focus:outline-none"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-red-600 px-5 py-3 text-xs font-bold text-white hover:bg-red-500 transition-colors"
            >
              Generate Link
            </button>
          </form>

          {generatedInvite && (
            <div className="mt-4 rounded-xl border border-zinc-700 bg-zinc-950 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in duration-200">
              <span className="font-code text-xs text-red-300 break-all">
                {generatedInvite}
              </span>
              <button
                onClick={handleCopyInvite}
                className="shrink-0 flex items-center justify-center gap-1.5 rounded-lg border border-red-500/50 bg-red-950/60 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-900 transition-colors"
              >
                {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedLink ? 'Link Copied!' : 'Copy Link'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
