import { 
  Faction, MemberProfile, LeaderboardEntry, ServerRule, LoreCharacter, 
  ScriptEpisode, ServerEvent, NewsPost, ScriptedRoleCategory 
} from '../types';

export const SERVER_CONFIG = {
  name: 'Vengeance',
  fullName: 'Vengeance Minecraft SMP',
  ip: 'vengeancesmp.playwithbao.com',
  bedrockIp: 'vengeancesmp.playwithbao.com',
  port: 25565,
  bedrockPort: 25565,
  version: '1.21.11',
  discordUrl: 'https://discord.gg/WX9rFvHhTb',
  slogan: 'Your story. Your choices. Your legacy.',
  description: 'Vengeance is a Minecraft SMP built around civilizations, player-driven stories, wars, events, mysteries, and exploration.'
};

export const SCRIPTED_ROLES_INFO: {
  category: ScriptedRoleCategory;
  tagline: string;
  description: string;
  responsibilities: string[];
  slots: string;
  badgeColor: string;
}[] = [
  {
    category: 'Main Characters',
    tagline: 'Driving the Core Narrative',
    description: 'Central figures whose decisions change the course of the story. Carry high stakes, canon consequences, and cinematic screen time.',
    responsibilities: ['Major plot progression', 'Lead civilization wars', 'Canon death encounters'],
    slots: 'Limited Audition Only',
    badgeColor: 'border-red-500/60 bg-red-950/40 text-red-300'
  },
  {
    category: 'Important Characters',
    tagline: 'Allies, Advisors & Regional Rulers',
    description: 'Influential allies, advisors, skilled specialists, and trusted companions who anchor crucial subplot arcs.',
    responsibilities: ['Support key characters', 'Shape important decisions', 'Drive subplot arcs'],
    slots: 'Open by Audition',
    badgeColor: 'border-purple-500/60 bg-purple-950/40 text-purple-300'
  },
  {
    category: 'Side Characters',
    tagline: 'The Soul of the Realm',
    description: 'Supporting characters, traders, scouts, and lore chroniclers who make the world feel alive, vibrant, and deep.',
    responsibilities: ['Community roleplay', 'Trading hubs', 'Information brokers'],
    slots: 'Actively Recruiter',
    badgeColor: 'border-blue-500/60 bg-blue-950/40 text-blue-300'
  },
  {
    category: 'Antagonists',
    tagline: 'Shadows, Tyrants & Chaos Agents',
    description: 'Rivals and mysterious figures whose choices test the resolve of the main characters.',
    responsibilities: ['Provoke conflict', 'Execute tactical ambushes', 'Drive story tension'],
    slots: 'Audition Required',
    badgeColor: 'border-rose-600/60 bg-rose-950/40 text-rose-300'
  },
  {
    category: 'Builders',
    tagline: 'Architects of Empires',
    description: 'Master artisans and builders responsible for creating memorable locations, ancient ruins, and mysterious monuments.',
    responsibilities: ['Civilization megabases', 'Lore dungeons & arenas', 'World aesthetics'],
    slots: 'Portfolio Application',
    badgeColor: 'border-amber-500/60 bg-amber-950/40 text-amber-300'
  },
  {
    category: 'PvPers',
    tagline: 'Frontline Champions & Gladiators',
    description: 'Competitive players who bring tension to duels, tournaments, and high-stakes story encounters.',
    responsibilities: ['Civilization defense', 'Tournament battles', 'High-intensity raids'],
    slots: 'Skill Assessment',
    badgeColor: 'border-emerald-500/60 bg-emerald-950/40 text-emerald-300'
  }
];

export const TIER_LIST_CATEGORIES = [
  {
    id: 'pvp',
    name: 'PvP',
    description: 'Crystal mechanics, 1.21 mace combat, sword tracking, totem cycling, and combat reaction time.',
    metrics: ['Crystal APM', 'Anchor Burst', 'Shield Disabling', 'Endurance']
  },
  {
    id: 'building',
    name: 'Building',
    description: 'Gothic architecture, terraforming, palette harmony, interior detailing, and mega-monument construction.',
    metrics: ['Scale & Proportion', 'Block Palette', 'Atmospheric Lighting', 'Speed']
  },
  {
    id: 'strategy',
    name: 'Strategy',
    description: 'Decision-making, tactical planning, resource management, and team coordination.',
    metrics: ['Tactical Foresight', 'Siege Engineering', 'Alliance Negotiation', 'Crisis Command']
  },
  {
    id: 'economy',
    name: 'Economy',
    description: 'Netherite treasury reserves, automated redstone farms, diamond trade monopoly, and commercial dominance.',
    metrics: ['Vault Wealth', 'Market Dominance', 'Resource Yield', 'Trade Routes']
  },
  {
    id: 'influence',
    name: 'Influence',
    description: 'Political charisma, server-wide respect, cultural impact, audience reach, and leadership reputation.',
    metrics: ['Diplomatic Weight', 'Story Relevance', 'Community Respect', 'Bounty Value']
  }
];

export const PROMOTION_CARDS = [
  {
    id: 'invite-friends',
    title: 'Invite Friends',
    tag: 'Community Growth',
    iconName: 'Users',
    description: 'Bring your friends and gaming circle into Vengeance. Bring your friends together and build a lasting story.',
    actionText: 'Generate Invite Link',
    perk: 'Special [Pioneer] in-game title for bringing 3+ friends'
  },
  {
    id: 'create-videos',
    title: 'Create Videos',
    tag: 'YouTube & Longform',
    iconName: 'Video',
    description: 'Record episodic series, cinema-grade documentaries, war recaps, and base tours. We provide replay mod support and camera accounts.',
    actionText: 'Apply for Creator Role',
    perk: 'Official [Creator] rank, priority queue & channel shoutouts'
  },
  {
    id: 'make-tiktoks',
    title: 'Make TikToks',
    tag: 'Shorts & TikTok',
    iconName: 'Smartphone',
    description: 'Share intense PvP clips, funny proximity chat moments, dramatic lore dialogue, and base builds on TikTok, Shorts, and Reels.',
    actionText: 'Submit Clip for Feature',
    perk: 'Weekly diamond bounties for viral clips over 10k views'
  },
  {
    id: 'promote-server',
    title: 'Promote the Server',
    tag: 'Advocacy',
    iconName: 'Megaphone',
    description: 'Vote for Vengeance on server lists, share our updates on Reddit and Twitter/X, and put our server IP in your Minecraft multiplayer list.',
    actionText: 'View Voting Links',
    perk: 'Daily vote crates with rare building blocks and cosmetics'
  },
  {
    id: 'partner-communities',
    title: 'Partner with Other Communities',
    tag: 'Alliances',
    iconName: 'Handshake',
    description: 'Are you an admin or leader of another gaming discord or Minecraft community? We host cross-server events, scrimmages, and tournaments.',
    actionText: 'Discuss Partnership',
    perk: 'Mutual Discord promotion and joint community events'
  },
  {
    id: 'bring-new-players',
    title: 'Bring New Players',
    tag: 'Ambassador',
    iconName: 'Sparkles',
    description: 'Help onboard fresh newcomers at spawn, guide them into thriving towns, teach 1.21 mechanics, and foster a welcoming yet competitive server.',
    actionText: 'Join Welcoming Team',
    perk: 'Unique server ambassador badge & event organizer permissions'
  }
];

export const FACTIONS: Record<string, Faction> = {
  obsidian: {
    id: 'obsidian',
    name: 'The Obsidian Syndicate',
    tag: 'OBS',
    color: '#a855f7',
    bannerColor: 'bg-purple-950/70 border-purple-800 text-purple-200',
    leader: 'KryoVex',
    motto: 'Forged in the Nether, sealed in the Void.',
    description: 'An aggressive military coalition entrenched in the Bedrock Basin. Masters of End Crystal warfare and underground fortress construction.',
    baseCoordinates: 'X: -1420 / Z: +890 (Bedrock Citadel)',
    territoryPercent: 44,
    activeWarWith: 'The Sunforge Imperium'
  },
  sunforge: {
    id: 'sunforge',
    name: 'The Sunforge Imperium',
    tag: 'SUN',
    color: '#eab308',
    bannerColor: 'bg-amber-950/70 border-amber-800 text-amber-200',
    leader: 'Lord_Aurelius',
    motto: 'Under the high sun, order shall prevail.',
    description: 'A disciplined paladin faction claiming the Central Highlands. Renowned for soaring monolithic architecture, trade monopolies, and heavy plate armor.',
    baseCoordinates: 'X: +600 / Z: -350 (The Sun Spire)',
    territoryPercent: 36,
    activeWarWith: 'The Obsidian Syndicate'
  },
  ashen: {
    id: 'ashen',
    name: 'The Ashen Outcasts',
    tag: 'ASH',
    color: '#ef4444',
    bannerColor: 'bg-red-950/70 border-red-800 text-red-200',
    leader: 'Vesper_Cain',
    motto: 'From the ashes of empires, we strike unseen.',
    description: 'A nomadic guerrilla faction operating from secret tunnels and nether roof outposts. Experts in traps, hit-and-run raids, and alchemical warfare.',
    baseCoordinates: 'X: -3200 / Z: -2100 (The Cinder Vault)',
    territoryPercent: 20,
    activeWarWith: 'None (Mercenary status)'
  }
};

export const SERVER_RULES: ServerRule[] = [
  {
    id: 'rule-1',
    number: 1,
    category: 'Combat & PvP',
    title: 'Combat Tagging & Disconnect Rules',
    shortDescription: 'Combat logging during an active PvP encounter results in an automatic kill NPC and penalty.',
    fullRule: 'Once attacked or initiating attack on another player, you are combat-tagged for 25 seconds. Logging out, disconnecting, or force-closing your client while combat-tagged spawns a vulnerable combat NPC that drops your entire inventory upon death. Deliberately bypassing combat tagging via network throttling or server crashes is strictly prohibited.',
    penalty: 'Inventory Wipe & Jail',
    severity: 'high',
    examplesAllowed: [
      'Retreating tactically using ender pearls, speed potions, or elytra',
      'Calling faction allies to counter-gank your attackers',
      'Drinking invisibility potions and sneaking away out of visual render'
    ],
    examplesProhibited: [
      'Pulling ethernet cable or killing Minecraft process while low on hearts',
      'Logging out inside an obsidian trap box during an active raid',
      'Using alt accounts to stall combat tag timers'
    ]
  },
  {
    id: 'rule-2',
    number: 2,
    category: 'Exploits & Fair Play',
    title: 'Zero-Tolerance Client Modifications & Hacks',
    shortDescription: 'Unfair advantages including X-ray, Fly, KillAura, Baritone, and crystal macros are banned.',
    fullRule: 'Vengeance enforces strict vanilla+ mechanics. Allowed client mods are purely performance or visual (Sodium, Lithium, Iris Shaders, Bobby, AppleSkin, MiniHUD without entity tracers). Any software, texture pack, or macro providing illegitimate information or automated combat triggers will result in an immediate hardware ID ban.',
    penalty: 'Permanent Ban',
    severity: 'critical',
    examplesAllowed: [
      'Sodium, Fabric API, Iris Shaders, FullBright gamma adjustments',
      'AppleSkin food saturation HUD, Simple Voice Chat mod',
      'Custom crosshair texture packs and vanilla GUI re-skins'
    ],
    examplesProhibited: [
      'X-Ray resource packs, X-Ray mod, or cave finder exploits',
      'Auto-Crystal, Auto-Totem, KillAura, BowAimbot, or Reach hacks',
      'Baritone automated mining, pathfinding, or bot farming scripts'
    ]
  },
  {
    id: 'rule-3',
    number: 3,
    category: 'Raiding & Griefing',
    title: 'Unscripted Raiding & Base Griefing Protocols',
    shortDescription: 'Raiding bases in unclaimed territory is allowed. Complete server lag cannons and spawn griefing are banned.',
    fullRule: 'In the Unscripted survival realm, player bases outside the 500-block Spawn Protection Zone may be infiltrated, raided, and looted. TNT cannons and wither skulls may be used against base walls. However, intentional server-crashing lag machines, lava-casting the world spawn perimeter, or griefing community public roads is forbidden.',
    penalty: '7-Day Ban',
    severity: 'high',
    examplesAllowed: [
      'Breaching an enemy bunker using TNT cannons, pickaxes, and ender pearls',
      'Looting chests, shulker boxes, beacon pyramids, and valuable ores',
      'Disabling enemy mob grinders or taking control of key nether portals'
    ],
    examplesProhibited: [
      'Building redstone lag-clocks designed to drop TPS below 10.0',
      'Creating cobblestone lava-casts within 500 blocks of the 0,0 world spawn',
      'Spawning 50+ Withers simultaneously to intentionally corrupt server chunk files'
    ]
  },
  {
    id: 'rule-4',
    number: 4,
    category: 'Economy & Trading',
    title: 'Bounties & Real World Trade Prohibitions',
    shortDescription: 'In-game diamond/netherite bounties are encouraged. Real Money Trading (RMT) is strictly banned.',
    fullRule: 'Players may place bounties on rivals using the server bounty system (/bounty place <player> <amount>) using in-game currency or diamonds. Real-world monetary transactions, exchanging real currency for in-game items or ranks, or extorting players for real money is an immediate permanent ban and reported to Mojang/Discord.',
    penalty: 'Permanent Ban',
    severity: 'critical',
    examplesAllowed: [
      'Placing a 64 Diamond Block bounty on an enemy warlord',
      'Bartering netherite gear for enchanted golden apples and totems',
      'Hiring mercenary factions to protect your shipment for in-game emeralds'
    ],
    examplesProhibited: [
      'Selling Minecraft items, bases, or Elytras for PayPal or crypto',
      'Trading Discord Nitro gifts in exchange for immunity or server perks',
      'Offering real money bribes to server moderators or staff'
    ]
  },
  {
    id: 'rule-5',
    number: 5,
    category: 'Combat & PvP',
    title: 'Spawn Camping & Newbie Grace Periods',
    shortDescription: 'New players receive a 3-hour PvP protection buffer unless they enter designated PvP warzones.',
    fullRule: 'To ensure a healthy server ecosystem, fresh recruits have a 3-hour peace buffer indicated by a glowing blue username. Hitting another player or opening chests in high-value loot dungeons immediately voids this protection. Spawn camping within the 0,0 buffer zone with endgame maxed netherite armor is forbidden.',
    penalty: '3-Day Ban',
    severity: 'medium',
    examplesAllowed: [
      'New players building starter bases undisturbed during their first 3 hours',
      'Veterans dueling in the Nether Fortresses or End Stronghold arenas',
      'Fighting players who have voluntary toggled PvP (/pvp on)'
    ],
    examplesProhibited: [
      'Lurking at the spawn gate with sharp 5 swords to slaughter leather-tier newcomers',
      'Trapping spawn exit portals with obsidian elder-guardian traps',
      'Repeatedly corpse-camping a player within 2 minutes of respawn'
    ]
  },
  {
    id: 'rule-6',
    number: 6,
    category: 'Community Conduct',
    title: 'Chat Decorum & Anti-Harassment Standards',
    shortDescription: 'Rival banter and faction rivalries are welcome; hate speech, doxxing, and swatting threats are permabanned.',
    fullRule: 'Competitive banter, roleplay hostility, and faction trash talk are natural parts of Vengeance. However, targeted harassment, racial slurs, homophobia, doxxing (releasing private real-world information), IP grabbing, or threatening real-world violence will result in immediate permanent expulsion without appeal.',
    penalty: 'Permanent Ban',
    severity: 'critical',
    examplesAllowed: [
      'Good-natured faction trash talk: "Your base fell in 4 minutes, Sunforge!"',
      'Announcing player bounties and declaring faction war declarations in global chat',
      'Organizing battle strategies in private team whisper channels'
    ],
    examplesProhibited: [
      'Posting real-world names, addresses, social media, or school locations',
      'Using hate speech, racial epithets, or severe personal harassment',
      'Sending phishing links or malicious grabber URLs in chat'
    ]
  }
];

export const MEMBER_PROFILES: MemberProfile[] = [
  {
    id: 'mem-1',
    username: 'KryoVex',
    role: 'Supreme Warlord',
    scriptedCategory: 'Main Characters',
    faction: 'obsidian',
    joinDate: 'Season 1 Day 1',
    kills: 412,
    deaths: 38,
    kdRatio: 10.84,
    bounty: 15400,
    playtimeHours: 842,
    favoriteWeapon: 'Void Cleaver',
    weaponLore: 'Netherite Axe · Sharpness V, Fire Aspect II, Unbreaking III · Forged in the Nether Bedrock basin',
    gearTier: 'Netherite Max',
    bio: 'Founding commander of The Obsidian Syndicate. Feared across all dimensions for unmatched End Crystal combat reaction speeds and calculated base sieges.',
    quote: 'Peace is merely the silence between two obsidian explosions.',
    avatarSeed: 'KryoVex',
    combatStyle: 'Crystal PvP Elite',
    canonLives: 2,
    status: 'Online',
    loadout: {
      helmet: 'Netherite Helm (Prot IV, Aqua Affinity, Respiration III)',
      chestplate: 'Netherite Chest (Prot IV, Unbreaking III, Mending)',
      leggings: 'Netherite Leggings (Swift Sneak III, Prot IV)',
      boots: 'Netherite Boots (Depth Strider III, Feather Falling IV)',
      mainHand: 'Void Cleaver (Netherite Axe, Sharp V)',
      offHand: 'Totem of Undying [x32 Stocked]',
      specialItems: ['End Crystals x128', 'Obsidian x256', 'Respawn Anchors', 'Enchanted Golden Apples x48']
    }
  },
  {
    id: 'mem-2',
    username: 'Lord_Aurelius',
    role: 'High Chancellor',
    scriptedCategory: 'Important Characters',
    faction: 'sunforge',
    joinDate: 'Season 1 Day 4',
    kills: 328,
    deaths: 45,
    kdRatio: 7.29,
    bounty: 12200,
    playtimeHours: 795,
    favoriteWeapon: 'Sol Invictus',
    weaponLore: 'Netherite Sword · Sweeping Edge III, Knockback II, Looting III · Golden trimmed blade',
    gearTier: 'Netherite Max',
    bio: 'Architect of the Sun Spire and undisputed ruler of the Central Plains. Believes the server requires absolute law and order under imperial rule.',
    quote: 'A fractured realm is a dead realm. Submit to the light, or burn in it.',
    avatarSeed: 'Aurelius',
    combatStyle: 'Aggressive Rusher',
    canonLives: 3,
    status: 'Online',
    loadout: {
      helmet: 'Golden Gilded Netherite Helm (Prot IV)',
      chestplate: 'Custom Sunforge Breastplate (Prot IV, Thorns III)',
      leggings: 'Netherite Greaves (Prot IV)',
      boots: 'Netherite Greaves (Prot IV, Soul Speed III)',
      mainHand: 'Sol Invictus (Netherite Sword)',
      offHand: 'Shield with Golden Phoenix Crest',
      specialItems: ['Strength II Splash Potions', 'Speed II Potions', 'Golden Carrots x128']
    }
  },
  {
    id: 'mem-3',
    username: 'Vesper_Cain',
    role: 'The Shadow Whisper',
    scriptedCategory: 'Side Characters',
    faction: 'ashen',
    joinDate: 'Season 1 Day 2',
    kills: 289,
    deaths: 31,
    kdRatio: 9.32,
    bounty: 9800,
    playtimeHours: 690,
    favoriteWeapon: 'Nightfall Bow',
    weaponLore: 'Power V, Flame, Punch II, Infinity · Marked with runic wither bone carvings',
    gearTier: 'Enchanted Hybrid',
    bio: 'Mastermind behind the Nether roof tunnel highway. Specializes in ambush snipes from 80 blocks away and covert intelligence trading.',
    quote: 'You cannot kill what you cannot see, and you cannot predict what has already been planned.',
    avatarSeed: 'VesperCain',
    combatStyle: 'Bow Sniper',
    canonLives: 1,
    status: 'Online',
    loadout: {
      helmet: 'Enchanted Netherite Hood (Blast Prot IV)',
      chestplate: 'Elytra (Unbreaking III, Mending)',
      leggings: 'Netherite Leggings (Prot IV)',
      boots: 'Leather Boots (Dyed Black, Feather Falling IV)',
      mainHand: 'Nightfall Bow (Infinity, Flame)',
      offHand: 'Firework Rockets (Duration 3)',
      specialItems: ['Invisibility Potions (8:00)', 'Splash Slowness IV', 'Chorus Fruit x64']
    }
  },
  {
    id: 'mem-4',
    username: 'Aetheria_',
    role: 'Redstone Technocrat',
    scriptedCategory: 'Builders',
    faction: 'obsidian',
    joinDate: 'Season 1 Day 12',
    kills: 194,
    deaths: 52,
    kdRatio: 3.73,
    bounty: 6400,
    playtimeHours: 910,
    favoriteWeapon: 'The Cannoner’s Wrench',
    weaponLore: 'Diamond Pickaxe · Efficiency V, Silk Touch, Unbreaking III · Key to automated artillery',
    gearTier: 'Diamond Pro',
    bio: 'Constructed the legendary perimeter trap network around the Bedrock Citadel. Can assemble a 12-barrel tunnel-bore cannon in under three minutes.',
    quote: 'Why swing a sword when 300 TNT blocks can solve the argument automatically?',
    avatarSeed: 'Aetheria',
    combatStyle: 'Trap Master',
    canonLives: 2,
    status: 'AFK',
    loadout: {
      helmet: 'Diamond Helmet (Prot IV)',
      chestplate: 'Netherite Chestplate (Blast Prot IV)',
      leggings: 'Diamond Leggings (Prot IV)',
      boots: 'Diamond Boots (Feather Falling IV)',
      mainHand: 'The Cannoner’s Wrench',
      offHand: 'Redstone Dust Stack',
      specialItems: ['Slime Blocks x64', 'Sticky Pistons x32', 'Dispensers x40', 'Water Buckets']
    }
  },
  {
    id: 'mem-5',
    username: 'Ironclad_Ben',
    role: 'Titan Vanguard',
    scriptedCategory: 'PvPers',
    faction: 'sunforge',
    joinDate: 'Season 1 Day 18',
    kills: 245,
    deaths: 62,
    kdRatio: 3.95,
    bounty: 5200,
    playtimeHours: 580,
    favoriteWeapon: 'Sunforged Warhammer',
    weaponLore: 'Netherite Mace & Axe combo · Maximum impact enchants',
    gearTier: 'Netherite Max',
    bio: 'Frontline vanguard for the Sunforge legions. Known to charge directly into crystal fire to shield lower-geared allies.',
    quote: 'Stand behind me. No one breaches the vanguard while I still draw breath.',
    avatarSeed: 'IroncladBen',
    combatStyle: 'Tactical Support',
    canonLives: 3,
    status: 'Offline',
    loadout: {
      helmet: 'Netherite Helm (Prot IV)',
      chestplate: 'Netherite Chest (Prot IV)',
      leggings: 'Netherite Leggings (Prot IV)',
      boots: 'Netherite Boots (Prot IV)',
      mainHand: 'Sunforged Warhammer',
      offHand: 'Enchanted Shield (Unbreaking III, Mending)',
      specialItems: ['Golden Apples x64', 'Turtle Master Potions', 'Splash Healing II']
    }
  },
  {
    id: 'mem-6',
    username: 'Nyx_Eclipse',
    role: 'Rogue Assassin',
    scriptedCategory: 'Antagonists',
    faction: 'lone_wolf',
    joinDate: 'Season 2 Day 3',
    kills: 310,
    deaths: 29,
    kdRatio: 10.68,
    bounty: 18900,
    playtimeHours: 640,
    favoriteWeapon: 'Widowmaker',
    weaponLore: 'Netherite Dagger · Sharpness V, Fire Aspect II · Poison-coated blade',
    gearTier: 'Netherite Max',
    bio: 'Holds the highest single active bounty on the server ($18,900). Belongs to no faction and hunts whoever commands the highest price.',
    quote: 'Factions are fairy tales told by men who fear dying alone.',
    avatarSeed: 'NyxEclipse',
    combatStyle: 'Aggressive Rusher',
    canonLives: 1,
    status: 'Online',
    loadout: {
      helmet: 'Netherite Helmet (Prot IV)',
      chestplate: 'Elytra + Netherite Chest swap',
      leggings: 'Netherite Leggings (Prot IV)',
      boots: 'Netherite Boots (Soul Speed III, Depth Strider III)',
      mainHand: 'Widowmaker',
      offHand: 'Totem of Undying',
      specialItems: ['Splash Poison II', 'Harming II Arrows', 'Ender Pearls x64']
    }
  }
];

export const LEADERBOARD_DATA: LeaderboardEntry[] = [
  { rank: 1, username: 'KryoVex', faction: 'obsidian', kills: 412, deaths: 38, kdRatio: 10.84, bounty: 15400, playtimeHours: 842, streak: 24, tier: 'Immortal' },
  { rank: 2, username: 'Nyx_Eclipse', faction: 'lone_wolf', kills: 310, deaths: 29, kdRatio: 10.68, bounty: 18900, playtimeHours: 640, streak: 19, tier: 'Immortal' },
  { rank: 3, username: 'Lord_Aurelius', faction: 'sunforge', kills: 328, deaths: 45, kdRatio: 7.29, bounty: 12200, playtimeHours: 795, streak: 14, tier: 'Grandmaster' },
  { rank: 4, username: 'Vesper_Cain', faction: 'ashen', kills: 289, deaths: 31, kdRatio: 9.32, bounty: 9800, playtimeHours: 690, streak: 16, tier: 'Grandmaster' },
  { rank: 5, username: 'Ironclad_Ben', faction: 'sunforge', kills: 245, deaths: 62, kdRatio: 3.95, bounty: 5200, playtimeHours: 580, streak: 8, tier: 'Warlord' },
  { rank: 6, username: 'Aetheria_', faction: 'obsidian', kills: 194, deaths: 52, kdRatio: 3.73, bounty: 6400, playtimeHours: 910, streak: 6, tier: 'Warlord' },
  { rank: 7, username: 'DuskRider_99', faction: 'ashen', kills: 182, deaths: 68, kdRatio: 2.68, bounty: 3800, playtimeHours: 420, streak: 5, tier: 'Veteran' },
  { rank: 8, username: 'SolarisBlade', faction: 'sunforge', kills: 165, deaths: 71, kdRatio: 2.32, bounty: 2900, playtimeHours: 512, streak: 7, tier: 'Veteran' },
  { rank: 9, username: 'ObsidianFang', faction: 'obsidian', kills: 154, deaths: 79, kdRatio: 1.95, bounty: 2400, playtimeHours: 390, streak: 4, tier: 'Gladiator' },
  { rank: 10, username: 'PhantomStep', faction: 'lone_wolf', kills: 142, deaths: 48, kdRatio: 2.96, bounty: 4100, playtimeHours: 360, streak: 9, tier: 'Gladiator' },
  { rank: 11, username: 'CinderGale', faction: 'ashen', kills: 128, deaths: 65, kdRatio: 1.97, bounty: 1800, playtimeHours: 310, streak: 3, tier: 'Gladiator' },
  { rank: 12, username: 'Valkyrie_Rose', faction: 'sunforge', kills: 119, deaths: 54, kdRatio: 2.20, bounty: 2100, playtimeHours: 295, streak: 4, tier: 'Gladiator' }
];

export const LORE_CHARACTERS: LoreCharacter[] = [
  {
    id: 'lore-1',
    username: 'KryoVex',
    characterName: 'General KryoVex of the Void',
    title: 'The Unforgiven Scourge',
    roleCategory: 'Main Characters',
    faction: 'obsidian',
    canonLives: 2,
    moralAlignment: 'Lawful Evil',
    characterArc: 'Formerly a loyal knight of the Sunforge court, KryoVex was betrayed and left to perish in the Nether Bedrock trenches. He resurfaced as the supreme leader of the Syndicate, seeking total annihilation of the monarchy.',
    keyMotive: 'Break the Sunforge Monolith and harness the Ancient Void Crystal.',
    signatureArtifact: 'The Eclipse Eye (A cursed Ender Eye weeping nether fire)',
    status: 'Alive',
    deaths: [
      {
        lifeNumber: 1,
        episodeTitle: 'The Banquet of Treason',
        episodeNumber: 4,
        killer: 'Lord_Aurelius',
        cause: 'Poisoned chalice followed by a push into the Molten Caldera',
        description: 'During peace negotiations at the Summit of Red Sand, Aurelius slipped lingering potion of harm into the victory toast, striking Kryo down into the magma lake.'
      }
    ]
  },
  {
    id: 'lore-2',
    username: 'Lord_Aurelius',
    characterName: 'Emperor Aurelius II',
    title: 'Light of the Monolith',
    roleCategory: 'Main Characters',
    faction: 'sunforge',
    canonLives: 3,
    moralAlignment: 'Lawful Good',
    characterArc: 'Heir to the ancient golden throne. Aurelius believes iron discipline and strict laws are the only things preventing the realm from crumbling into demonic anarchy.',
    keyMotive: 'Maintain divine order and construct the High Sky Shield over the continent.',
    signatureArtifact: 'Scepter of Dawn (Infused with radiant beacon power)',
    status: 'Alive',
    deaths: []
  },
  {
    id: 'lore-3',
    username: 'Vesper_Cain',
    characterName: 'Vesper the Grey',
    title: 'The Ashen Prophet',
    roleCategory: 'Important Characters',
    faction: 'ashen',
    canonLives: 1,
    moralAlignment: 'Chaotic Neutral',
    characterArc: 'A solitary scholar whose family library was burned in the First Great Fire. Now walks between factions selling forbidden secrets and prophecies.',
    keyMotive: 'Uncover the lost ancient civilization beneath the Stronghold before the war consumes it.',
    signatureArtifact: 'The Bound Grimoire of Nether Echoes',
    status: 'On Last Life',
    deaths: [
      {
        lifeNumber: 1,
        episodeTitle: 'The Library Firestorm',
        episodeNumber: 2,
        killer: 'Obsidian Strike Team',
        cause: 'Suffocation in collapsing obsidian vault',
        description: 'When Syndicate raiders set fire to the Great Archive, Vesper refused to leave the historical scrolls and was crushed under falling granite.'
      },
      {
        lifeNumber: 2,
        episodeTitle: 'The Bridge of Reckoning',
        episodeNumber: 8,
        killer: 'Nyx_Eclipse',
        cause: 'Pierced by tipped arrow of decay across the Ravine',
        description: 'Ambushed on the wooden rope bridge connecting the Nether fortress outposts. Fell 120 blocks into soul sand valley.'
      }
    ]
  },
  {
    id: 'lore-4',
    username: 'Nyx_Eclipse',
    characterName: 'Nyx, The Nameless Blade',
    title: 'The Sovereign Ghost',
    roleCategory: 'Antagonists',
    faction: 'lone_wolf',
    canonLives: 1,
    moralAlignment: 'Chaotic Evil',
    characterArc: 'An experimental subject created in the forbidden Alchemy Chambers who escaped during the prison riot. Bound to nobody, fearing nothing.',
    keyMotive: 'Eliminate every crowned ruler who took part in the Alchemy Trials.',
    signatureArtifact: 'Twin Netherite Kunai of Wither Mist',
    status: 'On Last Life',
    deaths: [
      {
        lifeNumber: 1,
        episodeTitle: 'Trial by Fire',
        episodeNumber: 6,
        killer: 'Ironclad_Ben',
        cause: 'Crushed beneath falling anvil trap during the Fortress Siege',
        description: 'Attempted to assassinate the Sunforge Prince in his private chambers, but triggered Ben’s defensive wire trap.'
      },
      {
        lifeNumber: 2,
        episodeTitle: 'Duel at the End Gateway',
        episodeNumber: 9,
        killer: 'KryoVex',
        cause: 'End Crystal detonation at point-blank range',
        description: 'Challenged KryoVex to a 1v1 for the dragon egg; was caught in a lethal double-crystal chain reaction.'
      }
    ]
  },
  {
    id: 'lore-5',
    username: 'Malakor_Void',
    characterName: 'Archmage Malakor',
    title: 'The Forgotten Regent',
    roleCategory: 'Antagonists',
    faction: 'obsidian',
    canonLives: 0,
    moralAlignment: 'True Neutral',
    characterArc: 'The former Grand Counselor who was banished to the End dimension. His spirit now haunts the server’s obsidian monoliths, speaking in cryptic whispers.',
    keyMotive: 'Guide a chosen warrior to break the seal of the Dragon Well.',
    signatureArtifact: 'The Shattered Orb of Telepathy',
    status: 'Fallen (Ghost)',
    deaths: [
      {
        lifeNumber: 1,
        episodeTitle: 'The Exile Protocol',
        episodeNumber: 1,
        killer: 'Council Decree',
        cause: 'Executed in the Gilded Colosseum',
        description: 'Condemned for tampering with forbidden void rituals.'
      },
      {
        lifeNumber: 2,
        episodeTitle: 'The Nether Roof Collapse',
        episodeNumber: 5,
        killer: 'Vesper_Cain',
        cause: 'TNT chain detonation in secret bunker',
        description: 'Vesper detonated 64 TNT to prevent Malakor from completing the Void Gate.'
      },
      {
        lifeNumber: 3,
        episodeTitle: 'The Eclipse Twilight (Season 2 Finale)',
        episodeNumber: 10,
        killer: 'Lord_Aurelius',
        cause: 'Smote by the Sunforge Broadsword in the End Shrine',
        description: 'Canon finale death. Aurelius struck Malakor down as the celestial alignment completed, shattering his final heart.'
      }
    ]
  }
];

export const SCRIPT_EPISODES: ScriptEpisode[] = [
  {
    id: 'ep-1',
    episodeNumber: 1,
    season: 1,
    title: 'The Shattered Crown',
    synopsis: 'The founding king of the server falls ill, leaving no rightful heir. Two warring factions—The Obsidian Syndicate and The Sunforge Imperium—clash at the Central Monolith to claim the ancient throne.',
    keyMoments: [
      'Discovery of the Ancient Rune Stone at 0,0',
      'KryoVex breaks away from the Imperial Guard',
      'The construction of the Bedrock Citadel begins'
    ],
    canonEvents: ['First blood spilled at the Spawn Fountain', 'Faction treaty declared void'],
    keyQuote: 'A kingdom without a crown is simply a graveyard waiting to be dug.',
    speaker: 'Lord_Aurelius',
    transcriptExcerpt: [
      { speaker: 'Aurelius', line: 'Put down the blade, Kryo. The Council has spoken. You cannot rule through fear.' },
      { speaker: 'KryoVex', line: 'Fear is the only currency this land honors. When the sun sets tonight, your precious council will be ash.' },
      { speaker: 'Vesper', line: 'Both of you are blind! Look to the southern skies—the rift is already widening!', stageDirection: 'Points tremblingly toward the smoking horizon' }
    ]
  },
  {
    id: 'ep-4',
    episodeNumber: 4,
    season: 1,
    title: 'The Banquet of Treason',
    synopsis: 'A fragile truce is called under the blood moon. Diplomats from all three factions meet in neutral territory, unaware that a deadly poison has been prepared for the Syndicate leadership.',
    keyMoments: [
      'The poisoned toast at the obsidian banquet table',
      'KryoVex loses his First Canon Life in the magma lake',
      'Full-scale warfare erupts in the Nether Hub'
    ],
    canonEvents: ['KryoVex loses Canon Life 1 (3 -> 2)', 'Nether Hub bridges demolished'],
    keyQuote: 'Never drink wine offered with a smiling blade.',
    speaker: 'KryoVex',
    transcriptExcerpt: [
      { speaker: 'Aurelius', line: 'To unity, General. May our swords rest in their scabbards.' },
      { speaker: 'KryoVex', line: 'To unity... *coughs violently, dropping chalice* What... what have you poured into this cup?!', stageDirection: 'Clutches throat as purple potion sparks surround his armor' },
      { speaker: 'Aurelius', line: 'Only justice, old friend. Guard the doors! Let none of the Syndicate leave alive!' }
    ]
  },
  {
    id: 'ep-8',
    episodeNumber: 8,
    season: 2,
    title: 'The Bridge of Reckoning',
    synopsis: 'A high-intensity raid on the Ashen Outposts turns into a deadly sniper showdown across the 100-block deep Nether Ravine.',
    keyMoments: [
      'Vesper Cain loses his Second Canon Life to Nyx’s tipped arrows',
      'Aetheria’s flying TNT bomber destroys the western gate',
      'Ironclad Ben rescues the wounded infantry'
    ],
    canonEvents: ['Vesper Cain loses Canon Life 2 (2 -> 1)', 'Ashen Fortress partially compromised'],
    keyQuote: 'When you are down to your last heart, you finally discover what you are willing to burn.',
    speaker: 'Vesper_Cain',
    transcriptExcerpt: [
      { speaker: 'Vesper', line: 'Hold the parapet! If the bridge falls, our retreat to the roof is severed!' },
      { speaker: 'Nyx', line: 'Your retreat was severed twenty minutes ago, scholar.', stageDirection: 'Fires poison tipped arrow from the shadows of the basalt pillar' },
      { speaker: 'Vesper', line: 'Nyx... you took gold from both sides... how could you...', stageDirection: 'Falls from the wooden planking into the crimson smoke below' }
    ]
  },
  {
    id: 'ep-10',
    episodeNumber: 10,
    season: 2,
    title: 'The Eclipse Twilight (Season Finale)',
    synopsis: 'The celestial alignment occurs. Archmage Malakor attempts to channel the Void Heart in the End dimension, triggering a three-way battle that claims a permanent casualty.',
    keyMoments: [
      'Final battle on the central obsidian pillar in The End',
      'Archmage Malakor permanently dies (Canon Life 0/3) and becomes a wandering ghost',
      'The Dragon Egg is stolen by an unknown rogue'
    ],
    canonEvents: ['Malakor permanently killed (0/3 Canon Lives)', 'The End Gateway sealed for 30 days'],
    keyQuote: 'My flesh may turn to stardust, but my curse will linger in every shadow you cast.',
    speaker: 'Archmage Malakor',
    transcriptExcerpt: [
      { speaker: 'Malakor', line: 'The portal is open! The stars weep for your insolence!', stageDirection: 'Levitating above the End Crystal cluster with glowing purple eyes' },
      { speaker: 'Aurelius', line: 'By the light of the Sunforge, your madness ends here! *strikes with Sol Invictus*', stageDirection: 'A blinding flash of golden light shatters the crystal, sending shockwaves across the void' },
      { speaker: 'Malakor', line: 'No... NO! The seal... it cannot be broken... *turns into ethereal mist as death chime rings*' }
    ]
  },
  {
    id: 'ep-11',
    episodeNumber: 11,
    season: 3,
    title: 'Echoes in the Deepslate (Current Arc)',
    synopsis: 'Ancient deep dark shrieks echo from the bedrock layer. With Malakor dead, the remaining warlords discover an Ancient City beneath spawn harboring forbidden warden relics.',
    keyMoments: [
      'Discovery of the Catalyzed Netherite Core',
      'Tense confrontation between KryoVex and Nyx Eclipse',
      'The red life warning: Nyx and Vesper are both on their final lives'
    ],
    canonEvents: ['Warden awakens in Sector 4', 'Nyx and Vesper enter Critical Danger State (1 Life)'],
    keyQuote: 'In the deepslate, even the whispers can summon a nightmare.',
    speaker: 'Aetheria_',
    transcriptExcerpt: [
      { speaker: 'Aetheria', line: 'Quiet! Do not sneak-sprint over those sensors! One more vibration and the beast emerges.' },
      { speaker: 'Nyx', line: 'Let it emerge. I need its heart to craft the Void Bane dagger.' },
      { speaker: 'KryoVex', line: 'You are on your last life, Nyx. One sonic boom from that beast, and your name is removed from the tablist forever.' }
    ]
  }
];

export const SERVER_EVENTS: ServerEvent[] = [
  {
    id: 'event-1',
    title: 'The Celestial Eclipse War (Season 3 Climax)',
    date: 'Saturday, 8:00 PM EST',
    type: 'Scripted Canon Event',
    description: 'The ancient deepslate seal beneath spawn weakens. The Obsidian Syndicate and Sunforge legions mobilize to secure the Warden Shrine.',
    location: 'Deep Dark Stronghold (X: 0 / Y: -52 / Z: 0)',
    status: 'Upcoming'
  },
  {
    id: 'event-2',
    title: 'Unscripted Anarchy Sprint 4: The Cinder Basin',
    date: 'Next Friday, 6:00 PM EST',
    type: 'Unscripted Launch',
    description: 'A 72-hour temporary vanilla+ survival world with a 2,000x2,000 border. Winner takes the $500 community bounty pool.',
    location: 'Temporary Realm (unscripted.vengeancesmp.playwithbao.com)',
    status: 'Upcoming'
  },
  {
    id: 'event-3',
    title: 'The Great Civilization Summit & Peace Council',
    date: 'Past Sunday',
    type: 'Civilization Summit',
    description: 'All 3 major factions agreed to a temporary trade pact to establish the community Nether railway highway.',
    location: 'The Sun Spire Grand Amphitheater',
    status: 'Completed'
  }
];

export const NEWS_POSTS: NewsPost[] = [
  {
    id: 'news-1',
    title: 'Vengeance Updated to Minecraft 1.21.11',
    date: 'October 2026',
    tag: 'Server Update',
    summary: 'Full compatibility with 1.21.11, Mace weapon balance adjustments, performance optimizations, and anti-cheat upgrades.',
    content: 'We have officially migrated Vengeance to Minecraft 1.21.11! Players can connect with either Java or Bedrock clients. The mace fall damage scaling has been fine-tuned for balanced competitive PvP, and trial chambers now offer custom lore enchantment books.'
  },
  {
    id: 'news-2',
    title: 'Unscripted SMP Season 3 Recap & VOD Submissions',
    date: 'October 2026',
    tag: 'Community',
    summary: 'Over 140 base raids were logged in the last temporary sprint. Creator POV submissions are now open for the highlight reel.',
    content: 'Thank you to everyone who recorded and streamed their POV! Our video editors are currently compiling the best moments. Submit your YouTube / TikTok clips in #creator-submissions.'
  },
  {
    id: 'news-3',
    title: 'Auditions Opened for Scripted SMP Roles',
    date: 'September 2026',
    tag: 'Roleplay',
    summary: 'Auditions for Main Characters, Antagonists, and Builders for the upcoming Season 3 second act are officially open.',
    content: 'Interested in becoming a core part of the storyline? Head over to our Discord and fill out the character application form to join the cast.'
  }
];

export const FAQ_ITEMS = [
  {
    question: 'How do I join Vengeance?',
    answer: 'Launch Minecraft (Version 1.21.11), go to Multiplayer, click "Add Server", and enter the server IP: vengeancesmp.playwithbao.com. Java and Bedrock players are both supported on the default port 25565.'
  },
  {
    question: 'What is the difference between Scripted SMP and Unscripted SMP?',
    answer: 'The Scripted SMP is our continuous storyline realm where players take on designated roles, fight in planned wars, carry 3 canon lives, and follow scripted lore chapters. The Unscripted SMP is a separate temporary server hosted every few weeks with zero script, raw hardcore survival, unrestricted raiding, and everyone recording their own raw POV.'
  },
  {
    question: 'Can I record or stream my POV on Vengeance?',
    answer: 'Yes! Everyone on both the Scripted and Unscripted SMP is warmly encouraged to record and stream. Content creators get custom ranks, access to spectator replay cameras, and can feature on the official website.'
  },
  {
    question: 'Are hacked clients or X-ray allowed?',
    answer: 'No. Vengeance enforces strict vanilla+ mechanics with an advanced server-side anti-cheat. X-ray packs, crystal macros, fly, reach, and automation bots are permanently banned.'
  },
  {
    question: 'How do I join the Scripted SMP cast?',
    answer: 'You can audition for roles (Main Characters, Important Characters, Antagonists, Builders, PvPers) via our Discord server in the #character-applications channel.'
  }
];

export const STAFF_MEMBERS = [
  { name: 'Bao (Server Owner & Lead Architect)', role: 'Owner / Developer', status: 'Active' },
  { name: 'KryoVex', role: 'Head of Story & Lore Director', status: 'Active' },
  { name: 'Lord_Aurelius', role: 'Community Manager & Event Coordinator', status: 'Active' },
  { name: 'Vesper_Cain', role: 'Lead Anticheat Engineer', status: 'Active' },
  { name: 'Aetheria_', role: 'Head of Technical Redstone & Builds', status: 'Active' }
];

export const LIVE_KILL_FEED_ITEMS = [
  { killer: 'KryoVex', victim: 'DuskRider_99', weapon: 'Void Cleaver', dimension: 'The Nether', timeAgo: '2m ago' },
  { killer: 'Nyx_Eclipse', victim: 'SolarisBlade', weapon: 'Widowmaker', dimension: 'Overworld (Spawn)', timeAgo: '6m ago' },
  { killer: 'Vesper_Cain', victim: 'ObsidianFang', weapon: 'Nightfall Bow (82m)', dimension: 'Nether Roof', timeAgo: '11m ago' },
  { killer: 'Lord_Aurelius', victim: 'CinderGale', weapon: 'Sol Invictus', dimension: 'The Sun Spire', timeAgo: '18m ago' },
  { killer: 'VoidReaper', victim: 'WanderingTrader', weapon: 'End Crystal', dimension: 'Overworld', timeAgo: '24m ago' }
];
